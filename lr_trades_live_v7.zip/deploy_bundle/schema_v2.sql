-- ============================================================
--  LR TRADES — Security migration (v1 -> v2)
--  Run ONCE in hPanel -> Databases -> phpMyAdmin -> SQL tab,
--  AFTER the original schema.sql. Adds email verification,
--  password reset, and login rate-limiting.
-- ============================================================

-- --- USERS: verification state -----------------------------
-- MySQL 8 / MariaDB 10.3+ support IF NOT EXISTS here. If yours
-- errors on that, drop the "IF NOT EXISTS" and ignore a
-- duplicate-column error on re-run.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS email_verified TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS verified_at    DATETIME NULL DEFAULT NULL;

-- Existing accounts predate verification — mark them verified so
-- turning on 'require_verified_email' never locks anyone out.
UPDATE users SET email_verified = 1, verified_at = NOW()
WHERE email_verified = 0;

-- --- EMAIL TOKENS (verify + reset) --------------------------
-- Only a SHA-256 hash of each token is stored; the raw token
-- lives only in the emailed link. Single-use, time-limited.
CREATE TABLE IF NOT EXISTS email_tokens (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT UNSIGNED    NOT NULL,
    token_hash  CHAR(64)        NOT NULL,
    purpose     ENUM('verify','reset') NOT NULL,
    expires_at  DATETIME        NOT NULL,
    used_at     DATETIME        NULL DEFAULT NULL,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_token_hash (token_hash),
    KEY idx_user_purpose (user_id, purpose),
    KEY idx_expires (expires_at),
    CONSTRAINT fk_tokens_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- AUTH ATTEMPTS (rate limiting) --------------------------
-- One row per attempt; failures counted within a sliding window.
-- action: 'login' | 'reset_request' | 'verify_resend'
CREATE TABLE IF NOT EXISTS auth_attempts (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    action      VARCHAR(32)     NOT NULL DEFAULT 'login',
    ip          VARBINARY(16)   NULL,
    email       VARCHAR(190)    NULL,
    success     TINYINT(1)      NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_ip_action_time    (ip, action, created_at),
    KEY idx_email_action_time (email, action, created_at),
    KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
