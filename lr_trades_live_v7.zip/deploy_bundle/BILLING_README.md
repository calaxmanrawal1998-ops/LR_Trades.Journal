# LR_TRADES — Billing & Subscriptions (Step 1)

This adds a **complete, creator-controlled billing system**: subscription plans
(monthly / yearly / lifetime / one-time), a coupon engine (percent / fixed /
**100%-off**), per-user subscriptions, invoices, an admin dashboard, and a
TradeZella-style pricing page. Everything is **provider-agnostic** — the actual
card processor plugs in later (Step 2) without touching any of this.

Card details never touch your server: paid checkout will hand off to the
processor's own hosted page.

---

## What's included now

**Backend**
- `db/billing_schema.sql` — plans, coupons, subscriptions, invoices,
  redemptions, a webhook/event log, an `app_settings` table, and a `users.is_admin` flag.
- `includes/billing.php` — the engine: entitlements, coupon evaluation,
  subscription activation, invoice creation, admin guard. Auto-loaded by `bootstrap.php`.
- `includes/gateways.php` — pluggable gateways. **ManualGateway works today**
  (free plans, 100%-off coupons, admin comps, offline/bank-transfer). Paddle /
  Stripe / Lemon Squeezy are stubs for Step 2.
- `api/billing/*` — `plans`, `me`, `redeem` (coupon preview), `subscribe`,
  `invoices`, `invoice_view` (printable HTML → Save as PDF).
- `api/admin/*` — `plans` (CRUD), `coupons`, `overview` (stats/subs/invoices),
  `grant` (comp a user / mark offline invoice paid / cancel), `settings`.

**Frontend**
- `pricing.html` — monthly/yearly toggle, plan cards, coupon field, checkout.
- `admin.html` — where **you** create plans, set prices, generate coupons,
  comp users, confirm offline payments, and tune the rules.

**Wired into your app**
- `api/me.php` now returns a `billing` block (entitlement/plan/status).
- The journal checks entitlement on load: if the paywall is ON and the user
  has no active plan (and isn't an admin), it routes them to `pricing.html`.
  A small plan chip (and an **Admin** link for admins) appears top-right.

---

## Deploy (once)

1. **Run the migration.** hPanel → Databases → phpMyAdmin → SQL tab →
   paste `db/billing_schema.sql` → Go. (Run it *after* `schema.sql` and
   `schema_v2.sql`.) It seeds a sample Free + Pro monthly/yearly you can edit or delete.

2. **Make yourself an admin.** In `includes/config.php`, set:
   ```php
   'billing' => [
       'admin_emails' => ['your-login-email@your-domain.com'],
       'default_currency' => 'USD',   // or 'NPR', 'INR', 'EUR', ...
       'active_gateway'   => 'manual',
   ],
   ```
   (Or set `users.is_admin = 1` on your row in phpMyAdmin.)

3. **Upload the new files**, preserving the folder layout
   (`db/`, `includes/`, `api/billing/`, `api/admin/`, `pricing.html`, `admin.html`,
   and the updated `bootstrap.php`, `me.php`, journal HTML).

4. **Open `admin.html`** while logged in. Create your plans, generate coupons,
   and set your rules under **Settings**.

That's it — you can already sell (offline/manual), give 100%-off codes, and comp users.

---

## How the pieces work

**Plans.** Pair a tier's monthly & yearly by giving them the **same
`group_code`** (e.g. `pro`). The pricing page groups by tier and toggles period.
Price is stored in the smallest unit (cents); the admin form takes major units.

**Coupons.**
- *Percent* `value 0–100` (**100 = free**), or *Fixed* amount off (in cents).
- Scope to specific tiers via `applies_to` (group codes), or leave blank for all.
- Limits: total `max_redemptions`, `per_user_limit`, `expires_at`.
- A **100%-off coupon activates the subscription instantly** with a $0 paid
  invoice — no processor needed. One-click "100% off" preset in the admin.

**Entitlement / paywall.** `Settings → Paywall`:
- *Off* → the journal stays free for everyone; plans are optional upgrades.
- *On* → the journal requires an active plan; non-subscribers land on `pricing.html`.
Admins always have access.

**Invoices.** Every activation writes an invoice (number like `LR-2026-000001`).
Users see theirs on the pricing page; you see all of them in the admin. `invoice_view.php`
renders a clean printable invoice (**browser → Save as PDF**). Server-side PDF
generation can be added later if you want emailed PDF attachments.

**Manual gateway (today).** For a paid plan with no live processor connected,
checkout creates an **open invoice** and holds access; you confirm the payment
(bank transfer, wallet, cash) via **Mark paid** in the admin, which activates the plan.

---

## Step 2 — connecting a live card processor (the decision below)

Because a Nepal-registered merchant can't use Stripe directly, the realistic
options are a **Merchant of Record** (handles global cards, tax, invoicing, and
discounts for you) or a US LLC + Stripe, or local gateways for NPR:

| Option | Good when | Notes |
|---|---|---|
| **Paddle** (MoR) | Selling globally | Mature, handles tax/invoices/refunds; ~5% + fee |
| **Stripe** (via US/UK LLC or Atlas) | You'll incorporate abroad | Lowest fees, best API; needs a foreign entity |
| **Lemon Squeezy** (MoR) | Simple global SaaS | Being merged into "Stripe Managed Payments" — check status |
| **eSewa / Khalti** | Buyers are in Nepal (NPR) | Great domestically; weak on recurring/international |

When you pick one, Step 2 fills in that gateway class in `gateways.php`
(`startCheckout` → hosted checkout URL) plus a webhook endpoint
(`api/billing/webhook.php`) that activates/renews subscriptions on payment —
reusing everything already built here. The `billing_events` table is already in
place for webhook idempotency.

---

## Notes / caveats
- PHP wasn't runtime-available where this was built, so files were validated
  structurally (bracket balance + JS parse), same as your v2/v3 modules.
  Do a quick smoke test after upload: create a plan, make a 100%-off coupon,
  subscribe with it, and confirm the invoice appears.
- Nothing here stores card data or asks for card details in your own forms —
  by design.
