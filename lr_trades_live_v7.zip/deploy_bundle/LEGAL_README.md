# LR_TRADES — Legal &amp; Info Pages

Seven themed, cross-linked pages have been added at the site root:

| File | Page |
|---|---|
| `about.html` | About Us |
| `help.html` | Help &amp; FAQ |
| `contact.html` | Contact Us (business name + address) |
| `terms.html` | Terms of Service |
| `privacy.html` | Privacy Policy |
| `refund.html` | Refund &amp; Cancellation Policy |
| `disclaimer.html` | Disclaimer (trading-risk / not financial advice) |

They match your emerald-aurora theme and link to each other (and back to the
journal/pricing) via a shared footer. The public **Pricing** page now links all of
them in its footer.

---

## ⚠ Before you publish

**These are tailored templates, not legal advice.** I'm not a lawyer. Please review
them — ideally with a professional familiar with Indian law — and replace every
placeholder. Placeholders are shown in a highlighted style like
`[COMPANY LEGAL NAME]`. Search the files for `[` to find them all. The main ones:

- `[COMPANY LEGAL NAME]` — your registered India entity.
- `[EFFECTIVE DATE]` — the date each policy takes effect.
- `[SUPPORT EMAIL]` — your support/contact email.
- `[BUSINESS ADDRESS, CITY, STATE, INDIA]` and `[CITY, INDIA]` — required by payment
  processors and for jurisdiction/governing-law clauses.
- `[GSTIN, if applicable]`, `[PHONE (optional)]`.
- `[GRIEVANCE OFFICER NAME / EMAIL]` — India's DPDP Act expects a contact for data
  grievances.
- `[Hostinger / hosting provider]`, `[your SMTP / email provider]` — keep the
  processor/sub-processor list accurate (Razorpay + NOWPayments are already named).
- Refund specifics: the `[7]`-day window, `[3–5 business days]`, `[5–10 business
  days]`, and the crypto-refund handling — set these to the policy you actually offer.

Tip: you could move these values into a small config later, but for launch it's
fastest to find-and-replace in the seven files.

---

## Why this matters for payments (Step 2)

Razorpay and NOWPayments both require, before activating a live merchant account,
that your site publicly show:

- **Terms &amp; Conditions** → `terms.html`
- **Privacy Policy** → `privacy.html`
- **Refund / Cancellation Policy** → `refund.html`
- **Contact Us with a business address** → `contact.html`
- A clear description of what you sell and its pricing → your `pricing.html`

So filling these in is part of unblocking live card/crypto checkout.

---

## Add the footer links to your other pages (optional but recommended)

The Pricing page already links these. To surface them on the sign-in page and the
journal too (good for users and for processor review), drop this near the bottom of
`LR_TRADES_signin_aurora.html` and/or `LR_TRADES_JOURNAL_v24_10.html`, just before
`</body>`:

```html
<div style="text-align:center;padding:20px;font:400 12.5px system-ui,sans-serif;
     color:rgba(238,240,246,.4)">
  <a style="color:#2fe0a0;text-decoration:none" href="about.html">About</a> ·
  <a style="color:#2fe0a0;text-decoration:none" href="help.html">Help</a> ·
  <a style="color:#2fe0a0;text-decoration:none" href="contact.html">Contact</a> ·
  <a style="color:#2fe0a0;text-decoration:none" href="terms.html">Terms</a> ·
  <a style="color:#2fe0a0;text-decoration:none" href="privacy.html">Privacy</a> ·
  <a style="color:#2fe0a0;text-decoration:none" href="refund.html">Refund</a> ·
  <a style="color:#2fe0a0;text-decoration:none" href="disclaimer.html">Disclaimer</a>
</div>
```

(I kept the edit out of those two large files to avoid touching working code; paste
it in whenever you like.)

---

## Home page &amp; cookie notice (added)

- **`index.html`** is now your public landing page (previously visitors hit the
  sign-in screen directly). Hostinger serves `index.html` as the site's default
  document automatically, so `https://your-domain.com/` will show it. Its buttons
  point to sign-in (`LR_TRADES_signin_aurora.html`) and `pricing.html`, and its
  footer links all the legal pages. The dashboard image on it is a **decorative
  mock** (dashes/placeholder curve) — no real numbers implied.
- An **essential-cookies notice** now appears on `index.html`, `pricing.html`, and
  all seven legal pages. It's dismissible and remembers the choice in the browser.
  Since LR_TRADES uses only a strictly-necessary session cookie, this is a courtesy
  notice; if you later add analytics/marketing cookies you'll need a fuller
  consent tool.

To add the same cookie notice to the sign-in and journal pages, paste this just
before `</body>` in `LR_TRADES_signin_aurora.html` and `LR_TRADES_JOURNAL_v24_10.html`:

```html
<div id="ck-consent" style="position:fixed;left:16px;right:16px;bottom:16px;max-width:720px;margin:0 auto;z-index:9999;display:flex;gap:14px;align-items:center;justify-content:space-between;flex-wrap:wrap;background:rgba(9,30,24,.96);border:1px solid rgba(47,224,160,.35);border-radius:14px;padding:14px 18px;box-shadow:0 10px 30px rgba(0,0,0,.45);font:400 13.5px/1.5 system-ui,sans-serif;color:#eef0f6">
  <span>We use only essential cookies to keep you signed in and run the app. See our <a href="privacy.html" style="color:#2fe0a0;text-decoration:none">Privacy Policy</a>.</span>
  <button onclick="lrCookieOk()" style="background:linear-gradient(135deg,#2fe0a0,#5ceaba);color:#04140d;border:0;border-radius:9px;padding:9px 18px;font:600 13.5px system-ui,sans-serif;cursor:pointer">Got it</button>
</div>
<script>(function(){try{if(localStorage.getItem('lr_cookie_ok')){var e=document.getElementById('ck-consent');if(e)e.style.display='none';}}catch(e){}})();
function lrCookieOk(){try{localStorage.setItem('lr_cookie_ok','1');}catch(e){}var el=document.getElementById('ck-consent');if(el)el.style.display='none';}</script>
```
