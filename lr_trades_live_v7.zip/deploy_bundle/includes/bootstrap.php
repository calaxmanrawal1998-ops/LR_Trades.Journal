<?php
/**
 * bootstrap.php — included at the top of every API endpoint.
 * Loads config, opens a PDO connection, starts a secure session,
 * and defines small JSON helpers.
 */

declare(strict_types=1);

// ---- Load config -------------------------------------------------
$configPath = __DIR__ . '/config.php';
if (!file_exists($configPath)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Server not configured. Copy config.example.php to config.php.']);
    exit;
}
$config = require $configPath;

// ---- Defaults for keys added after the initial release ----------
// Lets an existing config.php keep working without manual edits.
// (Fresh installs get these from the updated config.example.php.)
if (empty($config['app_url'])) {
    $scheme = (!empty($config['cookie_secure']) || (($_SERVER['HTTPS'] ?? '') === 'on')) ? 'https' : 'http';
    $config['app_url'] = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
}
$config += [
    'reset_page'             => '/reset.html',
    'signin_page'            => '/LR_TRADES_signin_aurora.html',
    'require_verified_email' => false,   // off unless explicitly enabled
    'verify_ttl'             => 86400,
    'reset_ttl'              => 3600,
];
$config['mail'] = ($config['mail'] ?? []) + [
    'from_email' => 'no-reply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost'),
    'from_name'  => 'LR_TRADES',
    'method'     => 'mail',
];
$config['mail']['smtp'] = ($config['mail']['smtp'] ?? []) + [
    'host' => 'smtp.hostinger.com', 'port' => 465, 'secure' => 'ssl', 'user' => '', 'pass' => '',
];
$config['ratelimit'] = ($config['ratelimit'] ?? []) + [
    'window' => 900, 'max_ip' => 30, 'lock_after' => 8, 'lock_time' => 900,
];
// Billing defaults (so an un-updated config.php keeps working).
$config['billing'] = ($config['billing'] ?? []) + [
    'admin_emails'     => [],       // these emails are always treated as admin
    'default_currency' => 'USD',
    'active_gateway'   => 'manual', // db setting overrides this at runtime
];

// ---- Secure session cookie --------------------------------------
$secure = !empty($config['cookie_secure']);
session_set_cookie_params([
    'lifetime' => 0,                 // session cookie (until browser closes)
    'path'     => '/',
    'domain'   => $config['cookie_domain'] ?: '',
    'secure'   => $secure,           // only sent over HTTPS
    'httponly' => true,              // not readable by JavaScript (XSS protection)
    'samesite' => 'Lax',             // CSRF mitigation
]);
session_name('LRSESSION');
session_start();

// ---- Database (PDO) ---------------------------------------------
try {
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'],
        $config['db_name']
    );
    $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    // Don't leak DB details to the client; log server-side instead.
    error_log('DB connection failed: ' . $e->getMessage());
    echo json_encode(['error' => 'Database connection failed.']);
    exit;
}

// ---- JSON helpers ------------------------------------------------
function json_out(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function json_in(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function require_login(): int {
    if (empty($_SESSION['user_id'])) {
        json_out(['error' => 'Not authenticated'], 401);
    }
    return (int) $_SESSION['user_id'];
}

// ---- Security helpers (rate limiting, tokens, email) ------------
require_once __DIR__ . '/security.php';

// ---- Billing engine (plans, coupons, subscriptions, invoices) --
require_once __DIR__ . '/billing.php';
