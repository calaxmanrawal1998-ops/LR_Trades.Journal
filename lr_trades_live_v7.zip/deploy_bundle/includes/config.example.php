<?php
/**
 * Copy this file to  config.php  and fill in your real values.
 * NEVER commit config.php with real credentials to git / public repos.
 *
 * You get these four values from hPanel when you create the MySQL
 * database and database user:
 *   hPanel → Databases → Management
 */

return [
    // --- Database (MySQL) ---
    'db_host' => 'localhost',          // On Hostinger shared hosting this is almost always 'localhost'
    'db_name' => 'uXXXXXXXX_lrtrades',  // e.g. u123456789_lrtrades
    'db_user' => 'uXXXXXXXX_lruser',    // e.g. u123456789_lruser
    'db_pass' => 'CHANGE_ME_STRONG_PASSWORD',

    // --- Session / cookie ---
    // Set to true once your site is served over HTTPS (it will be on Hostinger).
    'cookie_secure' => true,

    // Your site's domain, used for the cookie. Leave '' to auto-detect.
    'cookie_domain' => '',

    // --- Site URL (used to build links inside emails) ---
    // Public origin, NO trailing slash. e.g. 'https://your-domain.com'
    'app_url' => 'https://your-domain.com',

    // Path (relative to app_url) of the two auth pages, if you move them.
    'reset_page'  => '/reset.html',
    'signin_page' => '/LR_TRADES_signin_aurora.html',

    // --- Email verification ---
    // When true, a new account must confirm its email before it can log in.
    // Existing accounts are marked verified by the v2 migration, so turning
    // this on never locks out current users.
    'require_verified_email' => true,

    // --- Mail delivery ---
    // Create the mailbox first in hPanel -> Emails, then fill these in.
    'mail' => [
        'from_email' => 'no-reply@your-domain.com',
        'from_name'  => 'LR_TRADES',
        // 'smtp' (recommended, reaches the inbox) or 'mail' (PHP mail() fallback)
        'method'     => 'smtp',
        'smtp' => [
            'host'   => 'smtp.hostinger.com',
            'port'   => 465,          // 465 = SSL, 587 = STARTTLS
            'secure' => 'ssl',        // 'ssl' for 465, 'tls' for 587
            'user'   => 'no-reply@your-domain.com',
            'pass'   => 'CHANGE_ME',  // the mailbox password
        ],
    ],

    // --- Token lifetimes (seconds) ---
    'verify_ttl' => 60 * 60 * 24,   // 24h to confirm a new email
    'reset_ttl'  => 60 * 60,        // 1h  to use a password-reset link

    // --- Rate limiting (login / reset / resend) ---
    'ratelimit' => [
        'window'      => 900,  // sliding window, seconds
        'max_ip'      => 30,   // max failures per IP per window
        'lock_after'  => 8,    // account failures before lockout
        'lock_time'   => 900,  // lockout duration, seconds
    ],

    // --- Billing / subscriptions ---
    // Most billing rules (paywall on/off, currency, gateway, invoice text) are
    // edited live from the admin dashboard and stored in the app_settings table.
    // The values here are only bootstrap defaults + the admin allow-list.
    'billing' => [
        // Any account whose email is listed here is ALWAYS an admin, even
        // before you set users.is_admin = 1 in the database. Put your own
        // email here first so you can open admin.html.
        'admin_emails'     => ['you@your-domain.com'],

        'default_currency' => 'USD',   // 'USD' | 'EUR' | 'NPR' | 'INR' | ...

        // Which gateway handles paid checkout. 'manual' works today (free
        // plans, 100%-off coupons, comps, offline/bank-transfer). Set to
        // 'razorpay' (cards/UPI/international) or 'nowpayments' (crypto) once
        // you've onboarded and tested in sandbox. (100%-off always activates
        // instantly via the manual path regardless of this setting.)
        //   'razorpay' | 'nowpayments' | 'manual'
        'active_gateway'   => 'manual',

        // --- Razorpay (cards / UPI / netbanking / international) ---
        // Get keys: Razorpay Dashboard → Settings → API Keys (use TEST keys first).
        // Webhook: add  {app_url}/api/billing/webhook.php?provider=razorpay
        //   subscribing to: subscription.charged, subscription.activated,
        //   subscription.cancelled, subscription.halted, payment_link.paid
        // For each recurring plan, create a Razorpay Plan once and map it here.
        'razorpay' => [
            'key_id'         => '',
            'key_secret'     => '',
            'webhook_secret' => '',
            'plan_ids'       => [
                // 'pro_month' => 'plan_XXXXXXXXXXXXXX',
                // 'pro_year'  => 'plan_YYYYYYYYYYYYYY',
            ],
        ],

        // --- NOWPayments (crypto) ---
        // Get keys: NOWPayments Dashboard → Store Settings (API key + IPN secret).
        // Webhook (IPN): {app_url}/api/billing/webhook.php?provider=nowpayments
        'nowpayments' => [
            'api_key'    => '',
            'ipn_secret' => '',
        ],

        // Optional alternative (needs a foreign/US entity):
        'stripe' => [
            'secret_key'     => '',
            'publishable_key'=> '',
            'webhook_secret' => '',
            'price_ids'      => [],
        ],
    ],
];
