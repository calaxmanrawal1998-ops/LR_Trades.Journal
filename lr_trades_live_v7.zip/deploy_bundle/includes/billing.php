<?php
/**
 * billing.php — subscription / coupon / invoice engine (provider-agnostic).
 * Auto-loaded by bootstrap.php (after security.php). Uses the global $pdo
 * and $config already established there.
 *
 * Nothing here talks to a card network directly. Money movement goes through
 * a Gateway (see gateways.php); the "manual" gateway handles free plans,
 * 100%-off coupons, admin comps and offline/bank-transfer activation with no
 * external dependency. Live card checkout is added in step 2.
 */

declare(strict_types=1);

require_once __DIR__ . '/gateways.php';

// ---- Settings (creator-tunable, stored in app_settings) ----------
function billing_settings(): array {
    global $pdo;
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    try {
        foreach ($pdo->query('SELECT skey, sval FROM app_settings') as $r) {
            $cache[$r['skey']] = $r['sval'];
        }
    } catch (Throwable $e) { /* table may not exist yet */ }
    return $cache;
}
function setting(string $key, $default = null) {
    $s = billing_settings();
    return array_key_exists($key, $s) && $s[$key] !== null ? $s[$key] : $default;
}
function setting_set(string $key, $val): void {
    global $pdo;
    $pdo->prepare('INSERT INTO app_settings (skey, sval) VALUES (?, ?)
                   ON DUPLICATE KEY UPDATE sval = VALUES(sval)')
        ->execute([$key, (string)$val]);
}
function billing_currency(): string {
    return strtoupper((string)setting('default_currency', $GLOBALS['config']['billing']['default_currency'] ?? 'USD'));
}

// ---- Admin authorization -----------------------------------------
function user_is_admin(int $userId): bool {
    global $pdo, $config;
    $stmt = $pdo->prepare('SELECT is_admin, email FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $u = $stmt->fetch();
    if (!$u) return false;
    if ((int)$u['is_admin'] === 1) return true;
    $admins = array_map('strtolower', (array)($config['billing']['admin_emails'] ?? []));
    return in_array(strtolower((string)$u['email']), $admins, true);
}
function require_admin(): int {
    $uid = require_login();               // 401 if not logged in (from bootstrap)
    if (!user_is_admin($uid)) {
        json_out(['error' => 'Admin access required'], 403);
    }
    return $uid;
}

// ---- Money helpers -----------------------------------------------
function money_symbol(string $ccy): string {
    return ['USD'=>'$','EUR'=>'€','GBP'=>'£','INR'=>'₹','NPR'=>'रू','AUD'=>'A$','CAD'=>'C$']
        [strtoupper($ccy)] ?? (strtoupper($ccy) . ' ');
}
function money_format(int $cents, string $ccy): string {
    return money_symbol($ccy) . number_format($cents / 100, 2);
}
function period_label(string $p): string {
    return ['month'=>'/mo','year'=>'/yr','lifetime'=>' once','once'=>' once'][$p] ?? '';
}

// ---- Plans --------------------------------------------------------
function plans_active(): array {
    global $pdo;
    $rows = $pdo->query('SELECT * FROM plans WHERE is_active = 1 ORDER BY sort_order, price_cents')
                ->fetchAll();
    return array_map('plan_normalize', $rows);
}
function plan_get(int $id): ?array {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM plans WHERE id = ?');
    $stmt->execute([$id]);
    $r = $stmt->fetch();
    return $r ? plan_normalize($r) : null;
}
function plan_normalize(array $r): array {
    $r['id']          = (int)$r['id'];
    $r['price_cents'] = (int)$r['price_cents'];
    $r['trial_days']  = (int)$r['trial_days'];
    $r['is_active']   = (int)$r['is_active'];
    $r['is_featured'] = (int)$r['is_featured'];
    $r['sort_order']  = (int)$r['sort_order'];
    $r['features']    = $r['features'] ? (json_decode($r['features'], true) ?: []) : [];
    $r['price_display'] = money_format($r['price_cents'], $r['currency']);
    return $r;
}

// ---- Coupons ------------------------------------------------------
function coupon_find(string $code): ?array {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM coupons WHERE code = ?');
    $stmt->execute([strtoupper(trim($code))]);
    $r = $stmt->fetch();
    return $r ?: null;
}
/**
 * Validate a coupon for a given plan + user and compute the discount.
 * Returns ['ok'=>bool, 'error'=>?string, 'coupon'=>?row,
 *          'discount_cents'=>int, 'final_cents'=>int].
 */
function coupon_evaluate(?string $code, array $plan, int $userId): array {
    global $pdo;
    $price = (int)$plan['price_cents'];
    $out = ['ok'=>true, 'error'=>null, 'coupon'=>null, 'discount_cents'=>0, 'final_cents'=>$price];
    $code = $code !== null ? trim($code) : '';
    if ($code === '') return $out;

    $c = coupon_find($code);
    if (!$c)                                   return ['ok'=>false,'error'=>'Coupon not found','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];
    if ((int)$c['is_active'] !== 1)            return ['ok'=>false,'error'=>'Coupon is inactive','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];
    $now = new DateTime('now');
    if (!empty($c['starts_at']) && new DateTime($c['starts_at']) > $now)
                                               return ['ok'=>false,'error'=>'Coupon not active yet','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];
    if (!empty($c['expires_at']) && new DateTime($c['expires_at']) < $now)
                                               return ['ok'=>false,'error'=>'Coupon has expired','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];
    if ($c['max_redemptions'] !== null && (int)$c['times_redeemed'] >= (int)$c['max_redemptions'])
                                               return ['ok'=>false,'error'=>'Coupon fully redeemed','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];

    // Per-user limit
    $lim = (int)$c['per_user_limit'];
    if ($lim > 0) {
        $q = $pdo->prepare('SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id = ? AND user_id = ?');
        $q->execute([$c['id'], $userId]);
        if ((int)$q->fetchColumn() >= $lim)
            return ['ok'=>false,'error'=>'You have already used this coupon','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];
    }
    // Plan scope
    if (!empty($c['applies_to'])) {
        $scope = json_decode($c['applies_to'], true) ?: [];
        $ok = in_array($plan['group_code'], $scope, true)
           || in_array($plan['code'], $scope, true)
           || in_array((int)$plan['id'], array_map('intval', $scope), true);
        if (!$ok) return ['ok'=>false,'error'=>'Coupon does not apply to this plan','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];
    }
    if ($c['min_amount_cents'] !== null && $price < (int)$c['min_amount_cents'])
        return ['ok'=>false,'error'=>'Order below coupon minimum','coupon'=>null,'discount_cents'=>0,'final_cents'=>$price];

    // Compute discount
    if ($c['kind'] === 'percent') {
        $pct = max(0, min(100, (int)$c['value']));
        $discount = (int)floor($price * $pct / 100);
    } else { // fixed
        $discount = min($price, (int)$c['value']);
    }
    $final = max(0, $price - $discount);
    return ['ok'=>true,'error'=>null,'coupon'=>$c,'discount_cents'=>$discount,'final_cents'=>$final];
}

// ---- Subscriptions ------------------------------------------------
function subscription_active_for(int $userId): ?array {
    global $pdo;
    $stmt = $pdo->prepare(
        "SELECT * FROM subscriptions
          WHERE user_id = ?
            AND status IN ('trialing','active','comp','past_due')
            AND (current_period_end IS NULL OR current_period_end > NOW())
       ORDER BY (current_period_end IS NULL) DESC, current_period_end DESC
          LIMIT 1");
    $stmt->execute([$userId]);
    $r = $stmt->fetch();
    if (!$r) return null;
    // past_due only counts within the grace window
    if ($r['status'] === 'past_due') {
        $grace = (int)setting('grace_days', 3);
        if (!empty($r['current_period_end'])) {
            $cut = new DateTime($r['current_period_end']);
            $cut->modify("+{$grace} days");
            if (new DateTime('now') > $cut) return null;
        }
    }
    $r['id']      = (int)$r['id'];
    $r['plan_id'] = $r['plan_id'] !== null ? (int)$r['plan_id'] : null;
    return $r;
}

function entitlements_for(int $userId): array {
    $sub  = subscription_active_for($userId);
    $paywall = setting('paywall_enabled', '0') === '1';
    $isAdmin = user_is_admin($userId);
    $out = [
        'entitled'    => $isAdmin || !$paywall || $sub !== null,
        'paywall'     => $paywall,
        'is_admin'    => $isAdmin,
        'status'      => $sub['status'] ?? ($paywall ? 'none' : 'open'),
        'plan_code'   => $sub['plan_code'] ?? null,
        'plan_name'   => null,
        'period_end'  => $sub['current_period_end'] ?? null,
        'cancel_at_period_end' => isset($sub['cancel_at_period_end']) ? (bool)$sub['cancel_at_period_end'] : false,
        'features'    => [],
    ];
    if ($sub && $sub['plan_id']) {
        $p = plan_get((int)$sub['plan_id']);
        if ($p) { $out['plan_name'] = $p['name']; $out['features'] = $p['features']; }
    }
    return $out;
}

/**
 * Compute a period end from a start + billing period.
 */
function period_end_from(string $billingPeriod, DateTime $start): ?DateTime {
    $end = clone $start;
    switch ($billingPeriod) {
        case 'month':    $end->modify('+1 month'); return $end;
        case 'year':     $end->modify('+1 year');  return $end;
        case 'lifetime':
        case 'once':     return null;              // never expires
        default:         $end->modify('+1 month'); return $end;
    }
}

/**
 * Create or renew a subscription and its invoice. Used by the manual
 * gateway (free / 100%-off / comp / offline-confirmed) and, in step 2,
 * by the processor webhook once a real payment settles.
 *
 * $opts: provider, status, coupon(row|null), discount_cents, final_cents,
 *        paid(bool), provider_customer_id, provider_subscription_id,
 *        provider_invoice_id, note
 */
function activate_subscription(int $userId, array $plan, array $opts = []): array {
    global $pdo;
    $provider   = $opts['provider']   ?? 'manual';
    $status     = $opts['status']     ?? ($plan['billing_period'] === 'lifetime' ? 'active'
                                          : ((int)$plan['trial_days'] > 0 && ($opts['use_trial'] ?? false) ? 'trialing' : 'active'));
    $coupon     = $opts['coupon']     ?? null;
    $final      = (int)($opts['final_cents']    ?? $plan['price_cents']);
    $discount   = (int)($opts['discount_cents'] ?? 0);
    $paid       = (bool)($opts['paid'] ?? ($final === 0));  // free/100%-off count as settled

    $start = new DateTime('now');
    // Honor a trial window if requested and available
    if ($status === 'trialing' && (int)$plan['trial_days'] > 0) {
        $end = clone $start; $end->modify('+' . (int)$plan['trial_days'] . ' days');
    } else {
        $end = period_end_from($plan['billing_period'], $start);
    }

    $pdo->beginTransaction();
    try {
        // Supersede any prior open/active subscription for this user.
        $pdo->prepare("UPDATE subscriptions SET status='canceled', canceled_at=NOW(), updated_at=NOW()
                        WHERE user_id = ? AND status IN ('trialing','active','past_due','comp')")
            ->execute([$userId]);

        $ins = $pdo->prepare(
            "INSERT INTO subscriptions
               (user_id, plan_id, plan_code, status, provider, provider_customer_id,
                provider_subscription_id, coupon_id, current_period_start, current_period_end)
             VALUES (?,?,?,?,?,?,?,?,?,?)");
        $ins->execute([
            $userId, $plan['id'], $plan['code'], $status, $provider,
            $opts['provider_customer_id'] ?? null,
            $opts['provider_subscription_id'] ?? null,
            $coupon['id'] ?? null,
            $start->format('Y-m-d H:i:s'),
            $end ? $end->format('Y-m-d H:i:s') : null,
        ]);
        $subId = (int)$pdo->lastInsertId();

        // Invoice
        $invId = invoice_create([
            'user_id'         => $userId,
            'subscription_id' => $subId,
            'plan'            => $plan,
            'subtotal_cents'  => (int)$plan['price_cents'],
            'discount_cents'  => $discount,
            'total_cents'     => $final,
            'coupon_code'     => $coupon['code'] ?? null,
            'provider'        => $provider,
            'provider_invoice_id' => $opts['provider_invoice_id'] ?? null,
            'status'          => $paid ? 'paid' : 'open',
            'paid'            => $paid,
        ]);

        // Record coupon redemption + bump counter
        if ($coupon) {
            $pdo->prepare('INSERT INTO coupon_redemptions (coupon_id, user_id, subscription_id, invoice_id)
                           VALUES (?,?,?,?)')
                ->execute([$coupon['id'], $userId, $subId, $invId]);
            $pdo->prepare('UPDATE coupons SET times_redeemed = times_redeemed + 1 WHERE id = ?')
                ->execute([$coupon['id']]);
        }

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return [
        'subscription_id' => $subId,
        'invoice_id'      => $invId,
        'status'          => $status,
        'period_end'      => $end ? $end->format('Y-m-d H:i:s') : null,
    ];
}

/**
 * Renew an existing provider subscription (extend its period) or, if this is
 * the first confirmed payment, activate it. Used by the webhook. Each paid
 * cycle writes a paid invoice.
 */
function renew_or_activate(int $userId, array $plan, string $provider, ?string $providerSubId, int $paidCents, ?string $providerInvoiceId = null): array {
    global $pdo;
    if ($providerSubId) {
        $q = $pdo->prepare('SELECT * FROM subscriptions WHERE provider_subscription_id = ? ORDER BY id DESC LIMIT 1');
        $q->execute([$providerSubId]);
        $sub = $q->fetch();
        if ($sub) {
            $from = (!empty($sub['current_period_end']) && new DateTime($sub['current_period_end']) > new DateTime('now'))
                  ? new DateTime($sub['current_period_end']) : new DateTime('now');
            $end = period_end_from($plan['billing_period'], $from);
            $pdo->prepare("UPDATE subscriptions SET status='active', current_period_end=?, updated_at=NOW() WHERE id=?")
                ->execute([$end ? $end->format('Y-m-d H:i:s') : null, $sub['id']]);
            $inv = invoice_create([
                'user_id'=>$userId, 'subscription_id'=>(int)$sub['id'], 'plan'=>$plan,
                'subtotal_cents'=>$paidCents, 'total_cents'=>$paidCents,
                'provider'=>$provider, 'provider_invoice_id'=>$providerInvoiceId, 'status'=>'paid', 'paid'=>true,
            ]);
            return ['subscription_id'=>(int)$sub['id'], 'invoice_id'=>$inv, 'renewed'=>true];
        }
    }
    return activate_subscription($userId, $plan, [
        'provider'=>$provider, 'status'=>'active',
        'final_cents'=>$paidCents, 'discount_cents'=>max(0, (int)$plan['price_cents'] - $paidCents),
        'paid'=>true, 'provider_subscription_id'=>$providerSubId, 'provider_invoice_id'=>$providerInvoiceId,
    ]);
}

// ---- Invoices -----------------------------------------------------
function invoice_next_number(): string {
    global $pdo;
    $prefix = (string)setting('invoice_prefix', 'LR');
    $year   = date('Y');
    // Count existing invoices this year for a stable sequence.
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM invoices WHERE number LIKE ?");
    $stmt->execute(["$prefix-$year-%"]);
    $seq = ((int)$stmt->fetchColumn()) + 1;
    return sprintf('%s-%s-%06d', $prefix, $year, $seq);
}

function invoice_create(array $d): int {
    global $pdo;
    $plan  = $d['plan'] ?? null;
    $ccy   = $plan['currency'] ?? billing_currency();
    $paid  = (bool)($d['paid'] ?? false);
    $userSnap = null;
    if (!empty($d['user_id'])) {
        $u = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ?');
        $u->execute([$d['user_id']]);
        $userSnap = $u->fetch() ?: null;
    }
    $desc = $d['description'] ?? ($plan ? ($plan['name'] . ' — ' . ucfirst($plan['billing_period'])) : 'Subscription');
    $line = [[
        'label'      => $desc,
        'qty'        => 1,
        'unit_cents' => (int)($d['subtotal_cents'] ?? 0),
        'amount_cents' => (int)($d['subtotal_cents'] ?? 0),
    ]];
    $number = invoice_next_number();
    $stmt = $pdo->prepare(
        "INSERT INTO invoices
           (number, user_id, subscription_id, plan_code, description, currency,
            subtotal_cents, discount_cents, tax_cents, total_cents, amount_paid_cents,
            status, coupon_code, provider, provider_invoice_id, line_items,
            customer_snapshot, issued_at, paid_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?)");
    $stmt->execute([
        $number,
        $d['user_id'] ?? null,
        $d['subscription_id'] ?? null,
        $plan['code'] ?? ($d['plan_code'] ?? null),
        $desc,
        $ccy,
        (int)($d['subtotal_cents'] ?? 0),
        (int)($d['discount_cents'] ?? 0),
        (int)($d['tax_cents'] ?? 0),
        (int)($d['total_cents'] ?? 0),
        $paid ? (int)($d['total_cents'] ?? 0) : 0,
        $d['status'] ?? ($paid ? 'paid' : 'open'),
        $d['coupon_code'] ?? null,
        $d['provider'] ?? 'manual',
        $d['provider_invoice_id'] ?? null,
        json_encode($line),
        $userSnap ? json_encode($userSnap) : null,
        $paid ? date('Y-m-d H:i:s') : null,
    ]);
    return (int)$pdo->lastInsertId();
}

function invoice_get(int $id): ?array {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM invoices WHERE id = ?');
    $stmt->execute([$id]);
    $r = $stmt->fetch();
    return $r ?: null;
}
function invoices_for_user(int $userId): array {
    global $pdo;
    $stmt = $pdo->prepare('SELECT id, number, description, currency, total_cents, status, issued_at
                             FROM invoices WHERE user_id = ? ORDER BY id DESC LIMIT 100');
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}
