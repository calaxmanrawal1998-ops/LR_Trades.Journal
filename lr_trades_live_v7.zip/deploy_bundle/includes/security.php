<?php
/**
 * security.php — rate limiting, single-use tokens, and email delivery.
 * Included at the end of bootstrap.php, so json_out()/json_in() and the
 * $pdo connection and $config array are already available to callers.
 *
 * DB functions take $pdo explicitly; mail functions take the mail config.
 * No external dependencies (no Composer / PHPMailer).
 */

declare(strict_types=1);

/* ============================================================
 *  Rate limiting  (backed by the auth_attempts table)
 * ============================================================ */

function lr_client_ip(): ?string {
    // REMOTE_ADDR is the safe default on Hostinger shared hosting.
    return $_SERVER['REMOTE_ADDR'] ?? null;
}

function lr_ip_packed(?string $ip): ?string {
    if (!$ip) return null;
    $packed = @inet_pton($ip);
    return $packed === false ? null : $packed;
}

/** Returns ['allowed'=>bool, 'retry_after'=>int, 'reason'=>string]. */
function lr_rate_check(PDO $pdo, array $rl, string $action, ?string $email): array {
    $ip     = lr_ip_packed(lr_client_ip());
    $sinceW = date('Y-m-d H:i:s', time() - (int)$rl['window']);
    $sinceL = date('Y-m-d H:i:s', time() - (int)$rl['lock_time']);

    if ($ip !== null) {
        $st = $pdo->prepare(
            'SELECT COUNT(*) FROM auth_attempts
             WHERE ip = ? AND action = ? AND success = 0 AND created_at > ?');
        $st->execute([$ip, $action, $sinceW]);
        if ((int)$st->fetchColumn() >= (int)$rl['max_ip']) {
            return ['allowed' => false, 'retry_after' => (int)$rl['window'], 'reason' => 'ip'];
        }
    }

    if ($email !== null && $email !== '') {
        $st = $pdo->prepare(
            'SELECT COUNT(*) FROM auth_attempts
             WHERE email = ? AND action = ? AND success = 0 AND created_at > ?');
        $st->execute([$email, $action, $sinceL]);
        if ((int)$st->fetchColumn() >= (int)$rl['lock_after']) {
            return ['allowed' => false, 'retry_after' => (int)$rl['lock_time'], 'reason' => 'account'];
        }
    }

    return ['allowed' => true, 'retry_after' => 0, 'reason' => ''];
}

function lr_rate_record(PDO $pdo, string $action, ?string $email, bool $success): void {
    $pdo->prepare(
        'INSERT INTO auth_attempts (action, ip, email, success) VALUES (?, ?, ?, ?)')
        ->execute([$action, lr_ip_packed(lr_client_ip()), $email ?: null, $success ? 1 : 0]);

    if ($success && $email) {
        $pdo->prepare(
            'DELETE FROM auth_attempts WHERE email = ? AND action = ? AND success = 0')
            ->execute([$email, $action]);
    }

    if (random_int(1, 100) === 1) {
        $pdo->prepare('DELETE FROM auth_attempts WHERE created_at < (NOW() - INTERVAL 30 DAY)')
            ->execute();
    }
}

/** Emits a 429 (using bootstrap's json_out) and exits. */
function lr_rate_block(array $check): void {
    header('Retry-After: ' . max(1, (int)$check['retry_after']));
    $mins = (int)ceil($check['retry_after'] / 60);
    $msg  = $check['reason'] === 'account'
        ? "Too many attempts on this account. Try again in about {$mins} minute(s)."
        : "Too many attempts. Please wait about {$mins} minute(s) and try again.";
    json_out(['error' => $msg, 'rate_limited' => true], 429);
}

/* ============================================================
 *  Single-use, hashed, time-limited tokens
 * ============================================================ */

/** Issue a token; invalidates older unused tokens of the same purpose. */
function lr_issue_token(PDO $pdo, int $userId, string $purpose, int $ttl): string {
    $pdo->prepare(
        'UPDATE email_tokens SET used_at = NOW()
         WHERE user_id = ? AND purpose = ? AND used_at IS NULL')
        ->execute([$userId, $purpose]);

    $raw  = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);
    $exp  = date('Y-m-d H:i:s', time() + $ttl);

    $pdo->prepare(
        'INSERT INTO email_tokens (user_id, token_hash, purpose, expires_at)
         VALUES (?, ?, ?, ?)')
        ->execute([$userId, $hash, $purpose, $exp]);

    return $raw;
}

/** Consume a token; returns user_id or null. Single-use (race-safe). */
function lr_consume_token(PDO $pdo, string $raw, string $purpose): ?int {
    if (!preg_match('/^[a-f0-9]{64}$/', $raw)) return null;
    $hash = hash('sha256', $raw);

    $st = $pdo->prepare(
        'SELECT id, user_id FROM email_tokens
         WHERE token_hash = ? AND purpose = ? AND used_at IS NULL AND expires_at > NOW()
         LIMIT 1');
    $st->execute([$hash, $purpose]);
    $row = $st->fetch();
    if (!$row) return null;

    $upd = $pdo->prepare('UPDATE email_tokens SET used_at = NOW() WHERE id = ? AND used_at IS NULL');
    $upd->execute([$row['id']]);
    if ($upd->rowCount() !== 1) return null;

    return (int)$row['user_id'];
}

/* ============================================================
 *  Email delivery
 * ============================================================ */

function lr_mime_name(string $name): string {
    return preg_match('/[^\x20-\x7e]/', $name)
        ? '=?UTF-8?B?' . base64_encode($name) . '?='
        : $name;
}

/** Branded HTML shell (emerald aurora accent). */
function lr_email_shell(string $heading, string $body, string $btnLabel = '', string $btnUrl = ''): string {
    $btn = '';
    if ($btnLabel && $btnUrl) {
        $u = htmlspecialchars($btnUrl, ENT_QUOTES);
        $btn = '<tr><td style="padding:8px 0 24px;"><a href="' . $u . '" '
             . 'style="display:inline-block;background:#10b981;color:#04120c;text-decoration:none;'
             . 'font-weight:600;padding:12px 22px;border-radius:10px;font-size:15px;">'
             . htmlspecialchars($btnLabel) . '</a></td></tr>';
    }
    return '<!doctype html><html><body style="margin:0;background:#0a0f0d;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0a0f0d;padding:32px 0;">'
        . '<tr><td align="center"><table role="presentation" width="480" cellpadding="0" cellspacing="0" '
        . 'style="background:#111a16;border:1px solid #1e2f27;border-radius:16px;padding:32px;'
        . 'font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#dfeee8;">'
        . '<tr><td style="font-size:13px;letter-spacing:2px;color:#10b981;font-weight:700;padding-bottom:16px;">LR_TRADES</td></tr>'
        . '<tr><td style="font-size:20px;font-weight:700;color:#fff;padding-bottom:12px;">' . htmlspecialchars($heading) . '</td></tr>'
        . '<tr><td style="font-size:15px;line-height:1.55;color:#c3d6ce;padding-bottom:20px;">' . $body . '</td></tr>'
        . $btn
        . '<tr><td style="font-size:12px;color:#6f877d;border-top:1px solid #1e2f27;padding-top:16px;">'
        . 'If you did not request this, you can safely ignore this email.</td></tr>'
        . '</table></td></tr></table></body></html>';
}

/** Send an HTML email. Returns true/false; failures are logged, not shown. */
function lr_send_mail(array $mail, string $to, string $toName, string $subject, string $html): bool {
    $text = trim(preg_replace('/\s+/', ' ', strip_tags($html)));

    if (($mail['method'] ?? 'mail') === 'smtp') {
        try { return lr_smtp_send($mail, $to, $toName, $subject, $html, $text); }
        catch (Throwable $e) { error_log('[lr_mailer] SMTP failed: ' . $e->getMessage()); return false; }
    }

    $boundary = 'b' . bin2hex(random_bytes(12));
    $headers  = 'From: ' . lr_mime_name($mail['from_name']) . ' <' . $mail['from_email'] . ">\r\n"
              . "MIME-Version: 1.0\r\n"
              . 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
    $b  = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n$text\r\n\r\n";
    $b .= "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n$html\r\n\r\n";
    $b .= "--$boundary--\r\n";
    $ok = @mail($to, $subject, $b, $headers);
    if (!$ok) error_log('[lr_mailer] mail() returned false');
    return (bool)$ok;
}

function lr_smtp_send(array $mail, string $to, string $toName, string $subject, string $html, string $text): bool {
    $s = $mail['smtp'];
    $secure = $s['secure'] ?? 'ssl';
    $transport = ($secure === 'ssl' ? 'ssl://' : 'tcp://') . $s['host'];
    $ctx = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true]]);

    $fp = @stream_socket_client("$transport:{$s['port']}", $errno, $errstr, 20, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) throw new RuntimeException("connect failed: $errstr ($errno)");
    stream_set_timeout($fp, 20);

    $read = function () use ($fp): array {
        $data = '';
        while (($line = fgets($fp, 515)) !== false) {
            $data .= $line;
            if (isset($line[3]) && $line[3] === ' ') break;
        }
        return [(int)substr($data, 0, 3), $data];
    };
    $write  = function (string $c) use ($fp): void { fwrite($fp, $c . "\r\n"); };
    $expect = function (array $r, int $ok) { if ($r[0] !== $ok) throw new RuntimeException("SMTP expected $ok, got: " . trim($r[1])); };

    $expect($read(), 220);
    $ehlo = $_SERVER['SERVER_NAME'] ?? 'localhost';
    $write("EHLO $ehlo"); $expect($read(), 250);

    if ($secure === 'tls') {
        $write('STARTTLS'); $expect($read(), 220);
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            throw new RuntimeException('STARTTLS failed');
        }
        $write("EHLO $ehlo"); $expect($read(), 250);
    }

    $write('AUTH LOGIN'); $expect($read(), 334);
    $write(base64_encode($s['user'])); $expect($read(), 334);
    $write(base64_encode($s['pass'])); $expect($read(), 235);

    $write('MAIL FROM:<' . $mail['from_email'] . '>'); $expect($read(), 250);
    $write('RCPT TO:<' . $to . '>');
    $r = $read(); if ($r[0] !== 250 && $r[0] !== 251) throw new RuntimeException('RCPT rejected: ' . trim($r[1]));
    $write('DATA'); $expect($read(), 354);

    $boundary = 'b' . bin2hex(random_bytes(12));
    $host = $_SERVER['SERVER_NAME'] ?? 'localhost';
    $headers  = 'Date: ' . date('r') . "\r\n"
              . 'Message-ID: <' . bin2hex(random_bytes(16)) . '@' . $host . ">\r\n"
              . 'From: ' . lr_mime_name($mail['from_name']) . ' <' . $mail['from_email'] . ">\r\n"
              . 'To: ' . lr_mime_name($toName) . ' <' . $to . ">\r\n"
              . 'Subject: ' . lr_mime_name($subject) . "\r\n"
              . "MIME-Version: 1.0\r\n"
              . 'Content-Type: multipart/alternative; boundary="' . $boundary . "\"\r\n";
    $mime  = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n$text\r\n\r\n";
    $mime .= "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n$html\r\n\r\n";
    $mime .= "--$boundary--\r\n";
    $data = preg_replace('/^\./m', '..', $headers . "\r\n" . $mime);

    $write($data); $write('.'); $expect($read(), 250);
    $write('QUIT'); fclose($fp);
    return true;
}
