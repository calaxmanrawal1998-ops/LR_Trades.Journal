<?php
/**
 * gateways.php — pluggable payment gateways.
 *
 * A gateway turns a "checkout intent" (a user + plan + evaluated coupon) into
 * one of three outcomes:
 *   - activated : access granted immediately (free plan, 100%-off coupon,
 *                 admin comp). No external payment needed.
 *   - manual    : an open invoice was created; the creator confirms an
 *                 offline/bank-transfer payment from the admin dashboard.
 *   - redirect  : send the user to a hosted checkout URL (live processor).
 *
 * Only ManualGateway is implemented now. The processor gateways are stubs to
 * be completed in step 2 once you choose Paddle / Stripe / Lemon Squeezy / etc.
 * They intentionally do NOT capture card details in our own code — the live
 * flow will always hand off to the processor's hosted checkout page.
 */

declare(strict_types=1);

abstract class Gateway {
    abstract public function key(): string;

    /**
     * @param array $ctx  ['user_id','plan','eval'(coupon_evaluate result),'use_trial'?]
     * @return array       ['mode'=>'activated'|'manual'|'redirect', ...]
     */
    abstract public function startCheckout(array $ctx): array;

    /** Live processors override this (step 2). */
    public function handleWebhook(array $payload): array {
        return ['ok' => false, 'error' => 'Webhook not implemented for ' . $this->key()];
    }
}

/**
 * ManualGateway — no external processor.
 *  - final price 0  -> activate immediately (free / 100%-off / comp)
 *  - final price >0 -> create an OPEN invoice; creator marks it paid from
 *                      the admin dashboard (bank transfer, cash, wallet, etc.)
 */
class ManualGateway extends Gateway {
    public function key(): string { return 'manual'; }

    public function startCheckout(array $ctx): array {
        $userId = (int)$ctx['user_id'];
        $plan   = $ctx['plan'];
        $eval   = $ctx['eval'];
        $final  = (int)$eval['final_cents'];
        $coupon = $eval['coupon'] ?? null;

        if ($final === 0) {
            $res = activate_subscription($userId, $plan, [
                'provider'       => 'manual',
                'coupon'         => $coupon,
                'discount_cents' => (int)$eval['discount_cents'],
                'final_cents'    => 0,
                'paid'           => true,
                'use_trial'      => $ctx['use_trial'] ?? false,
            ]);
            return ['mode' => 'activated', 'result' => $res,
                    'message' => 'Your plan is now active.'];
        }

        // Paid but no live processor yet: record an open invoice + pending sub.
        $res = activate_subscription($userId, $plan, [
            'provider'       => 'manual',
            'status'         => 'past_due',   // access held until confirmed paid
            'coupon'         => $coupon,
            'discount_cents' => (int)$eval['discount_cents'],
            'final_cents'    => $final,
            'paid'           => false,
        ]);
        $support = setting('support_email', '');
        return [
            'mode'    => 'manual',
            'result'  => $res,
            'message' => 'An invoice has been created. ' .
                         ($support ? "Send payment and email $support to confirm; " : '') .
                         'access unlocks once the payment is confirmed.',
        ];
    }
}

// ---- tiny HTTP helper (cURL) for gateway REST calls ----
function gw_http(string $method, string $url, array $opts = []): array {
    $ch = curl_init($url);
    $headers = $opts['headers'] ?? [];
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 25,
        CURLOPT_HTTPHEADER     => $headers,
    ]);
    if (!empty($opts['basic_auth'])) curl_setopt($ch, CURLOPT_USERPWD, $opts['basic_auth']);
    if (isset($opts['json'])) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($opts['json']));
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    return ['code' => (int)$code, 'body' => $body ? (json_decode($body, true) ?: []) : [], 'error' => $err];
}

/**
 * RazorpayGateway — cards / UPI / netbanking / international, with native
 * Subscriptions for recurring plans (Razorpay handles the RBI e-mandate,
 * 72-hour pre-debit notice, tokenization, and renewals).
 *
 * Config: $config['billing']['razorpay'] = key_id, key_secret, webhook_secret,
 *         plan_ids (map OUR plan code => a Razorpay plan_id you create once).
 *
 *  ⚠ SANDBOX-READY SCAFFOLDING — verify field names against current Razorpay
 *    docs and TEST in the Razorpay test mode before going live.
 */
class RazorpayGateway extends Gateway {
    public function key(): string { return 'razorpay'; }
    private function cfg(): array { return $GLOBALS['config']['billing']['razorpay'] ?? []; }
    private function auth(): string { $c=$this->cfg(); return ($c['key_id'] ?? '') . ':' . ($c['key_secret'] ?? ''); }

    public function startCheckout(array $ctx): array {
        $c = $this->cfg();
        if (empty($c['key_id']) || empty($c['key_secret'])) {
            return ['mode' => 'error', 'error' => 'Razorpay is not configured yet.'];
        }
        $plan = $ctx['plan']; $userId = (int)$ctx['user_id'];
        $notes = ['user_id' => (string)$userId, 'plan_id' => (string)$plan['id'], 'plan_code' => $plan['code']];

        // Recurring (monthly/yearly) -> Razorpay Subscription (hosted short_url).
        if (in_array($plan['billing_period'], ['month','year'], true)) {
            $rzpPlanId = $c['plan_ids'][$plan['code']] ?? null;
            if (!$rzpPlanId) return ['mode'=>'error','error'=>'No Razorpay plan_id mapped for '.$plan['code'].' (set billing.razorpay.plan_ids).'];
            // total_count = how many cycles before it ends (e.g. ~10 years).
            $total = $plan['billing_period'] === 'year' ? 10 : 120;
            $r = gw_http('POST', 'https://api.razorpay.com/v1/subscriptions', [
                'basic_auth' => $this->auth(),
                'json' => [
                    'plan_id'     => $rzpPlanId,
                    'total_count' => $total,
                    'customer_notify' => 1,
                    'notes'       => $notes,
                    // TODO: to apply a percentage/fixed coupon here, attach a
                    // Razorpay Offer id via 'offer_id'. 100%-off never reaches
                    // this gateway (handled by the manual path in subscribe.php).
                ],
            ]);
            $url = $r['body']['short_url'] ?? null;
            if (!$url) return ['mode'=>'error','error'=>'Razorpay subscription create failed'];
            return ['mode'=>'redirect','url'=>$url];
        }

        // One-time (lifetime/once) -> Razorpay Payment Link (hosted short_url).
        $r = gw_http('POST', 'https://api.razorpay.com/v1/payment_links', [
            'basic_auth' => $this->auth(),
            'json' => [
                'amount'   => (int)$ctx['eval']['final_cents'],
                'currency' => $plan['currency'],
                'description' => $plan['name'] . ' (' . $plan['billing_period'] . ')',
                'notes'    => $notes,
                'notify'   => ['email' => false, 'sms' => false],
            ],
        ]);
        $url = $r['body']['short_url'] ?? null;
        if (!$url) return ['mode'=>'error','error'=>'Razorpay payment link failed'];
        return ['mode'=>'redirect','url'=>$url];
    }
}

/**
 * NOWPaymentsGateway — cryptocurrency (non-custodial, 300+ coins).
 * Crypto has no silent auto-renew, so each term is a hosted invoice the user
 * pays; on confirmation the webhook grants access for that plan's period.
 *
 * Config: $config['billing']['nowpayments'] = api_key, ipn_secret.
 *
 *  ⚠ SANDBOX-READY SCAFFOLDING — verify against current NOWPayments docs and
 *    test with their sandbox before going live.
 */
class NOWPaymentsGateway extends Gateway {
    public function key(): string { return 'nowpayments'; }
    private function cfg(): array { return $GLOBALS['config']['billing']['nowpayments'] ?? []; }

    public function startCheckout(array $ctx): array {
        $c = $this->cfg();
        if (empty($c['api_key'])) return ['mode'=>'error','error'=>'NOWPayments is not configured yet.'];
        $plan = $ctx['plan']; $userId = (int)$ctx['user_id'];
        $appUrl = rtrim((string)($GLOBALS['config']['app_url'] ?? ''), '/');
        // order_id encodes who + which plan so the IPN can grant the right access.
        $orderId = 'lr:' . $userId . ':' . $plan['id'] . ':' . bin2hex(random_bytes(4));
        $r = gw_http('POST', 'https://api.nowpayments.io/v1/invoice', [
            'headers' => ['x-api-key: ' . $c['api_key']],
            'json' => [
                'price_amount'     => round(((int)$ctx['eval']['final_cents']) / 100, 2),
                'price_currency'   => strtolower($plan['currency']),
                'order_id'         => $orderId,
                'order_description'=> $plan['name'] . ' (' . $plan['billing_period'] . ')',
                'ipn_callback_url' => $appUrl . '/api/billing/webhook.php?provider=nowpayments',
                'success_url'      => $appUrl . '/pricing.html?crypto=success',
                'cancel_url'       => $appUrl . '/pricing.html?crypto=cancel',
            ],
        ]);
        $url = $r['body']['invoice_url'] ?? null;
        if (!$url) return ['mode'=>'error','error'=>'NOWPayments invoice failed'];
        return ['mode'=>'redirect','url'=>$url];
    }
}

/** ---- Remaining processor stubs (optional alternatives) ---- */
class StripeGateway extends Gateway {
    public function key(): string { return 'stripe'; }
    public function startCheckout(array $ctx): array {
        return ['mode' => 'error', 'error' => 'Stripe is not connected (needs a foreign entity).'];
    }
}

function gateway_get(?string $key = null): Gateway {
    $key = $key ?: (string)setting('active_gateway', 'manual');
    switch ($key) {
        case 'razorpay':            return new RazorpayGateway();
        case 'nowpayments':
        case 'crypto':              return new NOWPaymentsGateway();
        case 'stripe':              return new StripeGateway();
        case 'manual':
        default:                    return new ManualGateway();
    }
}
