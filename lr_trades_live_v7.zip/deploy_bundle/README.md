# LR TRADES — Live multi-user setup (Hostinger Premium: PHP + MySQL)

This turns your local-only journal into a real website: users sign in on the
aurora page, and their trades live in a MySQL database so they sync across
devices. Passwords are stored as bcrypt hashes (via PHP password_hash).

Premium supports PHP + MySQL (no Node.js) — which is exactly what this uses.

## Files
  LR_TRADES_signin_aurora.html   login/signup page, wired to the API
  LR_TRADES_JOURNAL_v24_10.html  your journal, now gated + cloud-synced
  schema.sql                     run once in phpMyAdmin
  includes/config.example.php    copy to config.php, add DB credentials
  includes/bootstrap.php         DB connection + secure session + helpers
  includes/.htaccess             blocks web access to this folder
  api/register.php login.php logout.php me.php     auth
  api/sync_pull.php sync_push.php sync_delete.php  trades/prop/notes/goals sync

## How it works
- Login posts to api/login.php or api/register.php. On success the server sets a
  session cookie and the page sends the user to the journal.
- Gate: the journal calls api/me.php on load. No session -> redirect to login.
  Valid session -> the app reveals.
- Storage is a per-user DOCUMENT STORE. Your app keeps IndexedDB as a local
  cache, but every write also syncs to MySQL and every load pulls from MySQL
  first. The journal_docs table holds each trade / prop / note / goal as JSON,
  keyed by your app's own id — nothing about your rich trade objects (setups,
  psychology, checklist, chart images) is lost.
- Migration is automatic. The first time an existing user logs in, trades
  already in their browser are pushed up to the server.

## Deploy (~15 min)
1. hPanel -> Databases -> Management: create a MySQL database + user, grant
   access. Note host (usually localhost), db name, username, password.
2. hPanel -> phpMyAdmin -> your database -> SQL tab -> paste schema.sql -> run.
3. Copy includes/config.example.php to includes/config.php and fill in the four
   DB values. Keep cookie_secure => true (Hostinger serves HTTPS).
4. Upload everything into public_html so you get public_html/api/... ,
   public_html/includes/... and both HTML pages at the root.
   Optional: rename the aurora page to index.html so the domain root opens login.
5. Test: create an account -> land in the journal -> add a trade -> check
   journal_docs in phpMyAdmin -> open in another browser, sign in, trade is
   there -> Sign out from the sidebar -> wrong password shows a clear error.

## Filenames to know (if you rename anything)
- Journal -> login redirect: the gate script at top of <body> and lrSignOut()
  both use 'LR_TRADES_signin_aurora.html'.
- Login -> journal redirect: APP_URL near the top of the aurora page's script
  uses 'LR_TRADES_JOURNAL_v24_10.html'.
- API folder: both pages assume endpoints live at api/ alongside them.

## Security
- bcrypt passwords; PDO prepared statements; HttpOnly + Secure + SameSite=Lax
  session cookie, regenerated on login.
- config.php sits in /includes, blocked from the web by .htaccess.
- Login returns the same message for wrong email vs wrong password.

## Security additions (v2) — now included

Three hardening features are wired into the files above.

### 1. Login rate-limiting
Every login is checked against a sliding 15-minute window (per IP and per
account) before credentials are tested; too many failures return HTTP 429 with
Retry-After. A successful login clears that account's failures. Reset and
resend requests are limited too. Thresholds live in config.php under
'ratelimit'. Backed by the auth_attempts table.

### 2. Password reset + email verification
- api/request_reset.php  -> emails a single-use reset link (reset.html?token=…)
- api/reset_password.php  -> sets the new password from that link
- api/verify_email.php    -> confirms a new address (link from the signup email)
- api/resend_verification.php -> re-sends the confirmation link
Tokens are stored only as SHA-256 hashes, are single-use, and expire (reset 1h,
verify 24h). Endpoints never reveal whether an email is registered. The aurora
page's "Forgot password?" link and a "Resend confirmation email" prompt are
already wired.

Email verification is controlled by 'require_verified_email' in config.php:
- The shipped config.example.php sets it TRUE (new signups must confirm first).
- The v2 migration marks all EXISTING users verified, so turning it on never
  locks out current accounts.
- If you drop these files onto an install whose config.php predates them, it
  defaults to FALSE until you add the key — nothing breaks.

### 3. Chart images in file storage
- api/upload_chart.php stores an uploaded image under
  uploads/charts/<user_id>/ and returns a URL. The journal's dbPut() now
  offloads base64 chart screenshots to files automatically on save, so neither
  the local cache nor the database carries multi-MB blobs.
- migrate_images.php is a one-time CLI script that moves screenshots already in
  the database out to files. Run: `php migrate_images.php --dry-run` then
  `php migrate_images.php`.
- A .htaccess is written into uploads/ that disables script execution there.

## Deploy the v2 additions (~10 more min)
1. phpMyAdmin -> your database -> SQL tab -> paste schema_v2.sql -> run.
   (Adds email_verified/verified_at to users, plus email_tokens and
   auth_attempts. Marks existing users verified.)
2. Upload the new/changed files, keeping the same layout:
   - includes/security.php, includes/bootstrap.php (updated), includes/config.example.php (updated)
   - api/request_reset.php, reset_password.php, verify_email.php,
     resend_verification.php, upload_chart.php
   - api/login.php, api/register.php (updated)
   - reset.html at the web root; migrate_images.php at the project root
   - the two HTML pages (updated)
3. In config.php add the new blocks from config.example.php: app_url, mail,
   verify_ttl, reset_ttl, ratelimit, and require_verified_email. Create the
   no-reply mailbox in hPanel -> Emails and put its SMTP user/pass in 'mail'.
4. Send yourself a reset from "Forgot password?" to confirm mail delivery.
   If SMTP is blocked on your plan, set mail.method => 'mail' as a fallback.
5. Run the image migration (dry-run first). Confirm uploads/charts/ fills and
   the trade JSON now holds /uploads/... URLs.

## Notes
- Offline write queue: writes still save locally instantly and sync in the
  background; a failed sync re-syncs on next load. If an image upload fails
  offline, the screenshot stays inline as base64 and is offloaded on the next
  save — nothing is lost.
- If you sit behind a proxy/CDN, review lr_client_ip() in includes/security.php
  before trusting forwarded headers for rate limiting.

---

## Offline retry queue for chart-image uploads (added)

Chart screenshots are offloaded from base64 to file storage on save. Previously,
if that upload failed (offline, server hiccup, mid-save drop) the image silently
stayed as a multi-MB base64 blob inline — locally and in the cloud — and never
retried.

Now failed uploads are parked in a persistent IndexedDB store (`pending_uploads`,
DB v3) and retried automatically:

- **Triggers:** on reconnect (`online` event), on a 45s safety timer, at startup,
  and shortly after each failure.
- **Backoff:** 5s → 15s → 1m → 5m → 15m, capped at 30m per image.
- **On success:** the trade's base64 is rewritten to the returned file URL both
  locally and in the cloud (via the existing `LRSYNC.push`), and the in-memory
  list is updated.
- **Permanent errors (4xx** — too large / bad type**)** are dropped rather than
  retried forever; the base64 simply stays inline as before.
- **De-duplicated:** the same image for the same trade is never queued twice.
- **UI:** an unobtrusive "N charts syncing…" pill appears bottom-left while the
  queue is non-empty and disappears when it drains.

No server-side changes are required — it reuses `api/upload_chart.php` as-is.
All client-side, in `LR_TRADES_JOURNAL_v24_10.html`.
