<?php
require __DIR__ . '/../includes/bootstrap.php';
$userId = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$body   = json_in();
$store  = $body['store'] ?? '';
$itemId = (string)($body['id'] ?? '');
if (!in_array($store, ['trades', 'prop', 'notes', 'goals'], true) || $itemId === '') {
    json_out(['error' => 'store and id are required'], 422);
}

$stmt = $pdo->prepare('DELETE FROM journal_docs WHERE user_id = ? AND store = ? AND item_id = ?');
$stmt->execute([$userId, $store, $itemId]);

json_out(['ok' => true, 'deleted' => $stmt->rowCount()]);
