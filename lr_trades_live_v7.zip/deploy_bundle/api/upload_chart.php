<?php
require __DIR__ . '/../includes/bootstrap.php';
$userId = require_login();   // uses the existing LRSESSION

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

// Accepts JSON { data: "data:image/png;base64,..." } (what the journal sends)
// or a multipart file field named "image".
$MAX_BYTES = 6 * 1024 * 1024; // 6 MB
$bytes = null;

if (!empty($_FILES['image']['tmp_name']) && is_uploaded_file($_FILES['image']['tmp_name'])) {
    if (($_FILES['image']['size'] ?? 0) > $MAX_BYTES) json_out(['error' => 'Image too large'], 413);
    $bytes = file_get_contents($_FILES['image']['tmp_name']);
} else {
    $body = json_in();
    $data = (string)($body['data'] ?? '');
    if (preg_match('#^data:image/[a-zA-Z.+-]+;base64,#', $data)) {
        $data = substr($data, strpos($data, ',') + 1);
    }
    $decoded = base64_decode(strtr($data, ' ', '+'), true);
    if ($decoded === false) json_out(['error' => 'Invalid image data'], 422);
    if (strlen($decoded) > $MAX_BYTES) json_out(['error' => 'Image too large'], 413);
    $bytes = $decoded;
}

if (!$bytes) json_out(['error' => 'No image provided'], 422);

// Validate by real content, not filename.
$info = @getimagesizefromstring($bytes);
if ($info === false) json_out(['error' => 'Not a valid image'], 422);
$extByType = [IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];
$type = $info[2] ?? 0;
if (!isset($extByType[$type])) json_out(['error' => 'Unsupported image type'], 422);
$ext = $extByType[$type];

// Store at <web root>/uploads/charts/<user>/  (api/ is one level down).
$uploadsRoot = dirname(__DIR__) . '/uploads';
$userDir     = $uploadsRoot . '/charts/' . $userId;
if (!is_dir($userDir) && !mkdir($userDir, 0755, true) && !is_dir($userDir)) {
    error_log('[lr] could not create ' . $userDir);
    json_out(['error' => 'Storage error'], 500);
}

// Drop a hardening .htaccess once (blocks script execution under /uploads).
$ht = $uploadsRoot . '/.htaccess';
if (!is_file($ht)) {
    @file_put_contents($ht,
        "php_flag engine off\n<FilesMatch \"\\.(?i:php[0-9]?|phtml|pl|py|cgi|asp|sh)$\">\n  Require all denied\n</FilesMatch>\n");
}

$name = bin2hex(random_bytes(16)) . '.' . $ext;
if (file_put_contents("$userDir/$name", $bytes) === false) {
    json_out(['error' => 'Could not save image'], 500);
}

json_out(['ok' => true, 'url' => '/uploads/charts/' . $userId . '/' . $name]);
