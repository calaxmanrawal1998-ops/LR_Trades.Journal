<?php
// Printable invoice (HTML -> browser "Save as PDF"). Owner or admin only.
require __DIR__ . '/../../includes/bootstrap.php';
$uid = require_login();

$id  = (int)($_GET['id'] ?? 0);
$inv = invoice_get($id);
if (!$inv) { http_response_code(404); echo 'Invoice not found'; exit; }
if ((int)$inv['user_id'] !== $uid && !user_is_admin($uid)) {
    http_response_code(403); echo 'Forbidden'; exit;
}

$ccy   = $inv['currency'];
$cust  = $inv['customer_snapshot'] ? json_decode($inv['customer_snapshot'], true) : [];
$lines = $inv['line_items'] ? json_decode($inv['line_items'], true) : [];
$brand = htmlspecialchars((string)setting('brand_name', 'LR_TRADES'));
$footer= htmlspecialchars((string)setting('invoice_footer', ''));
$taxNote = htmlspecialchars((string)setting('tax_note', ''));
$fmt = fn($c) => htmlspecialchars(money_format((int)$c, $ccy));
$h   = fn($s) => htmlspecialchars((string)$s);
header('Content-Type: text/html; charset=utf-8');
?><!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Invoice <?= $h($inv['number']) ?></title>
<style>
  :root{--ink:#0c0f0d;--mut:#5b6b64;--line:#e4ebe7;--accent:#0e6f5e;}
  *{box-sizing:border-box}
  body{font:14px/1.5 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:var(--ink);margin:0;background:#f4f7f5;padding:32px}
  .sheet{max-width:760px;margin:0 auto;background:#fff;border:1px solid var(--line);border-radius:14px;padding:40px}
  .top{display:flex;justify-content:space-between;align-items:flex-start;gap:24px;margin-bottom:28px}
  .brand{font-size:22px;font-weight:800;letter-spacing:.4px;color:var(--accent)}
  .muted{color:var(--mut)}
  h1{font-size:15px;letter-spacing:.14em;text-transform:uppercase;color:var(--mut);margin:0 0 4px}
  .num{font-size:20px;font-weight:700}
  .status{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.05em}
  .paid{background:#dcfce7;color:#166534}.open{background:#fef9c3;color:#854d0e}
  .void,.refunded{background:#fee2e2;color:#991b1b}
  table{width:100%;border-collapse:collapse;margin:22px 0}
  th,td{text-align:left;padding:11px 8px;border-bottom:1px solid var(--line)}
  th{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--mut)}
  td.r,th.r{text-align:right}
  .totals{margin-left:auto;width:280px}
  .totals td{border:none;padding:6px 8px}
  .totals .grand td{border-top:2px solid var(--ink);font-weight:800;font-size:16px;padding-top:12px}
  .foot{margin-top:32px;color:var(--mut);font-size:12.5px;border-top:1px solid var(--line);padding-top:16px}
  .actions{max-width:760px;margin:0 auto 16px;text-align:right}
  button{font:inherit;font-weight:600;background:var(--accent);color:#fff;border:0;border-radius:9px;padding:9px 16px;cursor:pointer}
  @media print{body{background:#fff;padding:0}.sheet{border:0}.actions{display:none}}
</style></head><body>
<div class="actions"><button onclick="window.print()">Print / Save as PDF</button></div>
<div class="sheet">
  <div class="top">
    <div>
      <div class="brand"><?= $brand ?></div>
      <?php if ($taxNote): ?><div class="muted" style="margin-top:4px"><?= $taxNote ?></div><?php endif; ?>
    </div>
    <div style="text-align:right">
      <h1>Invoice</h1>
      <div class="num"><?= $h($inv['number']) ?></div>
      <div class="muted"><?= $h(date('j M Y', strtotime($inv['issued_at']))) ?></div>
      <div style="margin-top:8px"><span class="status <?= $h($inv['status']) ?>"><?= $h($inv['status']) ?></span></div>
    </div>
  </div>

  <div class="muted">Billed to</div>
  <div style="font-weight:600"><?= $h($cust['display_name'] ?? '') ?></div>
  <div class="muted"><?= $h($cust['email'] ?? '') ?></div>

  <table>
    <thead><tr><th>Description</th><th class="r">Qty</th><th class="r">Amount</th></tr></thead>
    <tbody>
      <?php foreach ($lines as $li): ?>
      <tr>
        <td><?= $h($li['label'] ?? '') ?></td>
        <td class="r"><?= (int)($li['qty'] ?? 1) ?></td>
        <td class="r"><?= $fmt($li['amount_cents'] ?? 0) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <table class="totals">
    <tr><td>Subtotal</td><td class="r"><?= $fmt($inv['subtotal_cents']) ?></td></tr>
    <?php if ((int)$inv['discount_cents'] > 0): ?>
    <tr><td>Discount<?= $inv['coupon_code'] ? ' (' . $h($inv['coupon_code']) . ')' : '' ?></td>
        <td class="r">-<?= $fmt($inv['discount_cents']) ?></td></tr>
    <?php endif; ?>
    <?php if ((int)$inv['tax_cents'] > 0): ?>
    <tr><td>Tax</td><td class="r"><?= $fmt($inv['tax_cents']) ?></td></tr>
    <?php endif; ?>
    <tr class="grand"><td>Total</td><td class="r"><?= $fmt($inv['total_cents']) ?></td></tr>
  </table>

  <?php if ($footer): ?><div class="foot"><?= $footer ?></div><?php endif; ?>
</div>
</body></html>
