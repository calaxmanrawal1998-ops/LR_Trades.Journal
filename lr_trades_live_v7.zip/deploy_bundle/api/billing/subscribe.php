<?php
// Start checkout for a plan (+ optional coupon) via the active gateway.
require __DIR__ . '/../../includes/bootstrap.php';
$uid = require_login();
$in  = json_in();

$plan = plan_get((int)($in['plan_id'] ?? 0));
if (!$plan || !$plan['is_active']) json_out(['ok'=>false,'error'=>'Unknown plan'], 404);

$eval = coupon_evaluate((string)($in['coupon'] ?? ''), $plan, $uid);
if (!$eval['ok']) json_out(['ok'=>false,'error'=>$eval['error']], 422);

// Free or 100%-off always activates instantly via the manual path — no need to
// bounce the user to a card/crypto processor for a zero-value charge.
$gateway = ((int)$eval['final_cents'] === 0) ? new ManualGateway() : gateway_get();
try {
    $r = $gateway->startCheckout([
        'user_id'   => $uid,
        'plan'      => $plan,
        'eval'      => $eval,
        'use_trial' => (int)$plan['trial_days'] > 0,
    ]);
} catch (Throwable $e) {
    error_log('[billing] checkout failed: ' . $e->getMessage());
    json_out(['ok'=>false,'error'=>'Could not start checkout'], 500);
}

if (($r['mode'] ?? '') === 'error') json_out(['ok'=>false,'error'=>$r['error']], 400);

json_out([
    'ok'           => true,
    'mode'         => $r['mode'],                       // activated | manual | redirect
    'message'      => $r['message'] ?? null,
    'checkout_url' => $r['url'] ?? null,                // set for redirect (step 2)
    'invoice_id'   => $r['result']['invoice_id'] ?? null,
]);
