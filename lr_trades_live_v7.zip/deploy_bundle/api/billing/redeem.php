<?php
// Preview a coupon against a plan (no state change).
require __DIR__ . '/../../includes/bootstrap.php';
$uid = require_login();
$in  = json_in();

$plan = plan_get((int)($in['plan_id'] ?? 0));
if (!$plan || !$plan['is_active']) json_out(['ok'=>false,'error'=>'Unknown plan'], 404);

$eval = coupon_evaluate((string)($in['coupon'] ?? ''), $plan, $uid);
json_out([
    'ok'             => $eval['ok'],
    'error'          => $eval['error'],
    'discount_cents' => $eval['discount_cents'],
    'final_cents'    => $eval['final_cents'],
    'final_display'  => money_format($eval['final_cents'], $plan['currency']),
    'is_free'        => $eval['final_cents'] === 0,
]);
