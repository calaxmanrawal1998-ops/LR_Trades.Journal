<?php
// Public: active plans (grouped by tier) + a little display config.
require __DIR__ . '/../../includes/bootstrap.php';

$plans = plans_active();
$groups = [];
foreach ($plans as $p) {
    $g = $p['group_code'];
    if (!isset($groups[$g])) {
        $groups[$g] = ['group_code'=>$g, 'name'=>$p['name'], 'description'=>$p['description'],
                       'is_featured'=>$p['is_featured'], 'features'=>$p['features'], 'prices'=>[]];
    }
    $groups[$g]['prices'][] = [
        'id'=>$p['id'], 'code'=>$p['code'], 'billing_period'=>$p['billing_period'],
        'price_cents'=>$p['price_cents'], 'currency'=>$p['currency'],
        'price_display'=>$p['price_display'], 'trial_days'=>$p['trial_days'],
    ];
}
json_out([
    'ok'       => true,
    'currency' => billing_currency(),
    'brand'    => setting('brand_name', 'LR_TRADES'),
    'groups'   => array_values($groups),
]);
