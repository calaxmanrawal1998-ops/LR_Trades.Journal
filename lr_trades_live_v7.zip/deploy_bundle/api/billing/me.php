<?php
// Current user's billing state: entitlement, subscription, invoices.
require __DIR__ . '/../../includes/bootstrap.php';
$uid = require_login();

$ent  = entitlements_for($uid);
$subs = subscription_active_for($uid);
$invoices = array_map(function($r){
    return [
        'id'=>(int)$r['id'], 'number'=>$r['number'], 'description'=>$r['description'],
        'total_display'=>money_format((int)$r['total_cents'], $r['currency']),
        'status'=>$r['status'], 'issued_at'=>$r['issued_at'],
    ];
}, invoices_for_user($uid));

json_out([
    'ok'           => true,
    'entitlements' => $ent,
    'subscription' => $subs ? [
        'plan_code'=>$subs['plan_code'], 'status'=>$subs['status'],
        'period_end'=>$subs['current_period_end'],
        'cancel_at_period_end'=>(bool)$subs['cancel_at_period_end'],
        'provider'=>$subs['provider'],
    ] : null,
    'invoices'     => $invoices,
]);
