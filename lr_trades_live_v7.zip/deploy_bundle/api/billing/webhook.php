<?php
/**
 * webhook.php — receives payment events from the live gateways and
 * activates / renews / cancels subscriptions.
 *
 *   Razorpay:    /api/billing/webhook.php?provider=razorpay
 *   NOWPayments: /api/billing/webhook.php?provider=nowpayments
 *
 * Security: every request is signature-verified against the provider's shared
 * secret, and each event id is recorded in `billing_events` so a replayed
 * webhook is processed at most once.
 *
 *  ⚠ SANDBOX-READY SCAFFOLDING — verify event names/paths against the current
 *    provider docs and test in sandbox before going live. Register this URL in
 *    each provider's dashboard and set the matching secret in config.php.
 */
require __DIR__ . '/../../includes/bootstrap.php';

$provider = $_GET['provider'] ?? '';
$raw = file_get_contents('php://input');

function wh_done(int $code, string $msg = 'ok'): void { http_response_code($code); echo $msg; exit; }

/** Record event id for idempotency. Returns false if already seen. */
function wh_once(string $provider, ?string $eventId, array $payload): bool {
    global $pdo;
    if (!$eventId) return true; // can't dedupe; proceed
    try {
        $pdo->prepare('INSERT INTO billing_events (provider, event_type, provider_event_id, payload, status)
                       VALUES (?,?,?,?,?)')
            ->execute([$provider, $payload['event'] ?? ($payload['payment_status'] ?? null), $eventId,
                       json_encode($payload), 'received']);
        return true;
    } catch (PDOException $e) {
        return false; // duplicate (unique key) -> already handled
    }
}

// ----------------------------------------------------------------- Razorpay
if ($provider === 'razorpay') {
    $secret = $config['billing']['razorpay']['webhook_secret'] ?? '';
    $sig = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';
    if ($secret === '' || !hash_equals(hash_hmac('sha256', $raw, $secret), $sig)) wh_done(400, 'bad signature');

    $p = json_decode($raw, true) ?: [];
    $eventId = $_SERVER['HTTP_X_RAZORPAY_EVENT_ID'] ?? ($p['payload']['payment']['entity']['id'] ?? null);
    if (!wh_once('razorpay', $eventId, $p)) wh_done(200, 'duplicate');

    $event = $p['event'] ?? '';
    try {
        if ($event === 'subscription.charged' || $event === 'subscription.activated') {
            $ent   = $p['payload']['subscription']['entity'] ?? [];
            $notes = $ent['notes'] ?? [];
            $plan  = plan_get((int)($notes['plan_id'] ?? 0));
            $uid   = (int)($notes['user_id'] ?? 0);
            $paid  = (int)($p['payload']['payment']['entity']['amount'] ?? ($plan['price_cents'] ?? 0));
            if ($plan && $uid) renew_or_activate($uid, $plan, 'razorpay', (string)($ent['id'] ?? ''), $paid,
                                                 $p['payload']['payment']['entity']['id'] ?? null);
        } elseif ($event === 'payment_link.paid') {
            $ent   = $p['payload']['payment_link']['entity'] ?? [];
            $notes = $ent['notes'] ?? [];
            $plan  = plan_get((int)($notes['plan_id'] ?? 0));
            $uid   = (int)($notes['user_id'] ?? 0);
            $paid  = (int)($ent['amount_paid'] ?? ($plan['price_cents'] ?? 0));
            if ($plan && $uid) activate_subscription($uid, $plan, [
                'provider'=>'razorpay', 'status'=>'active', 'final_cents'=>$paid, 'paid'=>true,
                'provider_invoice_id'=>$ent['id'] ?? null,
            ]);
        } elseif (in_array($event, ['subscription.cancelled','subscription.halted','subscription.paused'], true)) {
            $subId = $p['payload']['subscription']['entity']['id'] ?? '';
            $status = $event === 'subscription.halted' ? 'past_due' : 'canceled';
            if ($subId) $pdo->prepare("UPDATE subscriptions SET status=?, updated_at=NOW() WHERE provider_subscription_id=?")
                            ->execute([$status, $subId]);
        }
    } catch (Throwable $e) {
        error_log('[webhook razorpay] ' . $e->getMessage());
        wh_done(500, 'error');
    }
    wh_done(200);
}

// -------------------------------------------------------------- NOWPayments
if ($provider === 'nowpayments') {
    $secret = $config['billing']['nowpayments']['ipn_secret'] ?? '';
    $sig = $_SERVER['HTTP_X_NOWPAYMENTS_SIG'] ?? '';
    // NOWPayments signs an alphabetically-sorted JSON body with HMAC-SHA512.
    $sorted = json_decode($raw, true) ?: [];
    ksort_recursive($sorted);
    $calc = hash_hmac('sha512', json_encode($sorted, JSON_UNESCAPED_SLASHES), $secret);
    if ($secret === '' || !hash_equals($calc, $sig)) wh_done(400, 'bad signature');

    $p = $sorted;
    $eventId = ($p['payment_id'] ?? '') . '-' . ($p['payment_status'] ?? '');
    if (!wh_once('nowpayments', $eventId, $p)) wh_done(200, 'duplicate');

    // Grant access once the crypto payment is confirmed/finished.
    if (in_array($p['payment_status'] ?? '', ['confirmed','finished'], true)) {
        // order_id we sent looks like  lr:<userId>:<planId>:<rand>
        $parts = explode(':', (string)($p['order_id'] ?? ''));
        if (($parts[0] ?? '') === 'lr') {
            $uid  = (int)($parts[1] ?? 0);
            $plan = plan_get((int)($parts[2] ?? 0));
            $paid = (int)round(((float)($p['price_amount'] ?? 0)) * 100);
            try {
                if ($plan && $uid) renew_or_activate($uid, $plan, 'nowpayments',
                    (string)($p['payment_id'] ?? $p['order_id'] ?? ''), $paid, (string)($p['payment_id'] ?? ''));
            } catch (Throwable $e) {
                error_log('[webhook nowpayments] ' . $e->getMessage());
                wh_done(500, 'error');
            }
        }
    }
    wh_done(200);
}

wh_done(400, 'unknown provider');

// --- helper: recursively sort keys (for NOWPayments signature) ---
function ksort_recursive(&$arr): void {
    if (is_array($arr)) { ksort($arr); foreach ($arr as &$v) ksort_recursive($v); }
}
