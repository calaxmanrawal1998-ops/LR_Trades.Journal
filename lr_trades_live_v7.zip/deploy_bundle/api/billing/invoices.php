<?php
require __DIR__ . '/../../includes/bootstrap.php';
$uid = require_login();
$rows = array_map(function($r){
    return [
        'id'=>(int)$r['id'], 'number'=>$r['number'], 'description'=>$r['description'],
        'total_display'=>money_format((int)$r['total_cents'], $r['currency']),
        'status'=>$r['status'], 'issued_at'=>$r['issued_at'],
    ];
}, invoices_for_user($uid));
json_out(['ok'=>true, 'invoices'=>$rows]);
