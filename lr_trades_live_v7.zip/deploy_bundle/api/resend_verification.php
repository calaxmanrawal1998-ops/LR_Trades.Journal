<?php
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$body  = json_in();
$email = strtolower(trim($body['email'] ?? ''));

$rl = lr_rate_check($pdo, $config['ratelimit'], 'verify_resend', $email ?: null);
if (!$rl['allowed']) lr_rate_block($rl);

$generic = ['ok' => true, 'message' => 'If that account still needs verification, a new link is on its way.'];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    lr_rate_record($pdo, 'verify_resend', $email ?: null, false);
    json_out($generic);
}

$stmt = $pdo->prepare('SELECT id, display_name, email_verified FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && (int)$user['email_verified'] === 0) {
    $raw  = lr_issue_token($pdo, (int)$user['id'], 'verify', (int)$config['verify_ttl']);
    $link = rtrim($config['app_url'], '/') . '/api/verify_email.php?token=' . $raw;
    $html = lr_email_shell(
        'Confirm your email',
        'Confirm your email address to finish setting up your LR_TRADES account.',
        'Verify email',
        $link
    );
    lr_send_mail($config['mail'], $email, $user['display_name'] ?: $email, 'Confirm your LR_TRADES email', $html);
}

lr_rate_record($pdo, 'verify_resend', $email ?: null, true);
json_out($generic);
