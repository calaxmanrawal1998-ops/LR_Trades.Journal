<?php
// Admin: read/update creator-tunable rules (app_settings).
require __DIR__ . '/../../includes/bootstrap.php';
require_admin();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') json_out(['ok'=>true, 'settings'=>billing_settings()]);

if ($method === 'POST' || $method === 'PATCH') {
    $in = json_in();
    $allowed = ['paywall_enabled','default_currency','trial_days_default','grace_days',
                'active_gateway','allow_bank_transfer','brand_name','support_email',
                'invoice_prefix','invoice_footer','tax_note'];
    foreach ($in as $k => $v) {
        if (in_array($k, $allowed, true)) setting_set($k, is_bool($v) ? ($v?'1':'0') : (string)$v);
    }
    json_out(['ok'=>true]);
}
json_out(['ok'=>false,'error'=>'Method not allowed'], 405);
