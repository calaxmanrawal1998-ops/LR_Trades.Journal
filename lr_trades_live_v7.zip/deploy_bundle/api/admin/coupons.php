<?php
// Admin coupon management.  GET list | POST create | PATCH toggle/edit
require __DIR__ . '/../../includes/bootstrap.php';
require_admin();
global $pdo;
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rows = $pdo->query('SELECT * FROM coupons ORDER BY id DESC')->fetchAll();
    foreach ($rows as &$r) {
        $r['applies_to'] = $r['applies_to'] ? json_decode($r['applies_to'], true) : null;
        $r['value'] = (int)$r['value'];
    }
    json_out(['ok'=>true, 'coupons'=>$rows]);
}

$in = json_in();

if ($method === 'POST') {
    $code = strtoupper(trim((string)($in['code'] ?? '')));
    if ($code === '') json_out(['ok'=>false,'error'=>'code required'], 422);
    $kind = in_array($in['kind'] ?? 'percent', ['percent','fixed'], true) ? $in['kind'] : 'percent';
    $value = (int)($in['value'] ?? 0);
    if ($kind === 'percent') $value = max(0, min(100, $value));   // 100 => free
    $applies = !empty($in['applies_to']) ? json_encode(array_values((array)$in['applies_to'])) : null;
    $row = [
        'code'=>$code, 'kind'=>$kind, 'value'=>$value,
        'currency'=> $kind==='fixed' ? strtoupper(substr((string)($in['currency'] ?? billing_currency()),0,3)) : null,
        'duration'=> in_array($in['duration'] ?? 'once', ['once','repeating','forever'], true) ? $in['duration'] : 'once',
        'duration_months'=> isset($in['duration_months']) ? (int)$in['duration_months'] : null,
        'max_redemptions'=> isset($in['max_redemptions']) && $in['max_redemptions']!=='' ? (int)$in['max_redemptions'] : null,
        'per_user_limit'=> (int)($in['per_user_limit'] ?? 1),
        'applies_to'=> $applies,
        'min_amount_cents'=> isset($in['min_amount_cents']) && $in['min_amount_cents']!=='' ? (int)$in['min_amount_cents'] : null,
        'starts_at'=> !empty($in['starts_at']) ? $in['starts_at'] : null,
        'expires_at'=> !empty($in['expires_at']) ? $in['expires_at'] : null,
        'is_active'=> !empty($in['is_active']) ? 1 : 0,
        'note'=> isset($in['note']) ? substr((string)$in['note'],0,190) : null,
    ];
    try {
        $pdo->prepare('INSERT INTO coupons (code,kind,value,currency,duration,duration_months,max_redemptions,per_user_limit,applies_to,min_amount_cents,starts_at,expires_at,is_active,note)
            VALUES (:code,:kind,:value,:currency,:duration,:duration_months,:max_redemptions,:per_user_limit,:applies_to,:min_amount_cents,:starts_at,:expires_at,:is_active,:note)')
            ->execute($row);
    } catch (PDOException $e) {
        json_out(['ok'=>false,'error'=>'Coupon code already exists'], 409);
    }
    json_out(['ok'=>true, 'id'=>(int)$pdo->lastInsertId()]);
}

if ($method === 'PATCH') {
    $id = (int)($in['id'] ?? 0);
    if (!$id) json_out(['ok'=>false,'error'=>'id required'], 422);
    // Only allow toggling active / editing limits + expiry (not the discount itself, to keep issued codes stable).
    $pdo->prepare('UPDATE coupons SET is_active=:a, expires_at=:e, max_redemptions=:m WHERE id=:id')
        ->execute([
            'a'=> !empty($in['is_active']) ? 1 : 0,
            'e'=> !empty($in['expires_at']) ? $in['expires_at'] : null,
            'm'=> isset($in['max_redemptions']) && $in['max_redemptions']!=='' ? (int)$in['max_redemptions'] : null,
            'id'=>$id,
        ]);
    json_out(['ok'=>true]);
}
json_out(['ok'=>false,'error'=>'Method not allowed'], 405);
