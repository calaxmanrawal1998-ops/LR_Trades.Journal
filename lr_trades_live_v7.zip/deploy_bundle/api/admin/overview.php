<?php
// Admin dashboard data: headline stats, recent subs, recent invoices, settings.
require __DIR__ . '/../../includes/bootstrap.php';
require_admin();
global $pdo;

$ccy = billing_currency();
$active = (int)$pdo->query("SELECT COUNT(*) FROM subscriptions
    WHERE status IN ('active','trialing','comp')
      AND (current_period_end IS NULL OR current_period_end > NOW())")->fetchColumn();
$trialing = (int)$pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status='trialing'
      AND (current_period_end IS NULL OR current_period_end > NOW())")->fetchColumn();
$users = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$paidThisMonth = (int)$pdo->query("SELECT COALESCE(SUM(amount_paid_cents),0) FROM invoices
    WHERE status='paid' AND YEAR(paid_at)=YEAR(NOW()) AND MONTH(paid_at)=MONTH(NOW())")->fetchColumn();
$paidAll = (int)$pdo->query("SELECT COALESCE(SUM(amount_paid_cents),0) FROM invoices WHERE status='paid'")->fetchColumn();
$openInv = (int)$pdo->query("SELECT COUNT(*) FROM invoices WHERE status='open'")->fetchColumn();

$subs = $pdo->query("SELECT s.id, s.plan_code, s.status, s.provider, s.current_period_end,
                            u.email, u.display_name
                       FROM subscriptions s JOIN users u ON u.id=s.user_id
                      ORDER BY s.id DESC LIMIT 25")->fetchAll();

$invs = $pdo->query("SELECT i.id, i.number, i.total_cents, i.currency, i.status, i.issued_at, u.email
                       FROM invoices i JOIN users u ON u.id=i.user_id
                      ORDER BY i.id DESC LIMIT 25")->fetchAll();
foreach ($invs as &$iv) { $iv['total_display'] = money_format((int)$iv['total_cents'], $iv['currency']); }

json_out([
    'ok' => true,
    'stats' => [
        'active_subscriptions' => $active,
        'trialing'             => $trialing,
        'total_users'          => $users,
        'open_invoices'        => $openInv,
        'revenue_month'        => money_format($paidThisMonth, $ccy),
        'revenue_all'          => money_format($paidAll, $ccy),
    ],
    'subscriptions' => $subs,
    'invoices'      => $invs,
    'settings'      => billing_settings(),
]);
