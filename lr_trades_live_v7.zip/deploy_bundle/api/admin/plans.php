<?php
// Admin plan CRUD.  GET list | POST create | PATCH update | DELETE deactivate
require __DIR__ . '/../../includes/bootstrap.php';
require_admin();
global $pdo;
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rows = $pdo->query('SELECT * FROM plans ORDER BY sort_order, price_cents')->fetchAll();
    json_out(['ok'=>true, 'plans'=>array_map('plan_normalize', $rows)]);
}

$in = json_in();
$fields = function(array $in): array {
    return [
        'code'          => substr(trim((string)($in['code'] ?? '')), 0, 40),
        'group_code'    => substr(trim((string)($in['group_code'] ?? 'default')), 0, 40) ?: 'default',
        'name'          => substr(trim((string)($in['name'] ?? '')), 0, 80),
        'description'   => $in['description'] !== null ? substr((string)$in['description'], 0, 255) : null,
        'billing_period'=> in_array($in['billing_period'] ?? 'month', ['month','year','lifetime','once'], true) ? $in['billing_period'] : 'month',
        'price_cents'   => max(0, (int)($in['price_cents'] ?? 0)),
        'currency'      => strtoupper(substr((string)($in['currency'] ?? billing_currency()), 0, 3)),
        'trial_days'    => max(0, (int)($in['trial_days'] ?? 0)),
        'features'      => json_encode(array_values(array_filter(array_map('strval', (array)($in['features'] ?? []))))),
        'is_active'     => !empty($in['is_active']) ? 1 : 0,
        'is_featured'   => !empty($in['is_featured']) ? 1 : 0,
        'sort_order'    => (int)($in['sort_order'] ?? 0),
    ];
};

if ($method === 'POST') {
    $f = $fields($in);
    if ($f['code'] === '' || $f['name'] === '') json_out(['ok'=>false,'error'=>'code and name are required'], 422);
    try {
        $sql = 'INSERT INTO plans (code,group_code,name,description,billing_period,price_cents,currency,trial_days,features,is_active,is_featured,sort_order)
                VALUES (:code,:group_code,:name,:description,:billing_period,:price_cents,:currency,:trial_days,:features,:is_active,:is_featured,:sort_order)';
        $pdo->prepare($sql)->execute($f);
    } catch (PDOException $e) {
        json_out(['ok'=>false,'error'=>'Duplicate plan code?'], 409);
    }
    json_out(['ok'=>true, 'id'=>(int)$pdo->lastInsertId()]);
}

if ($method === 'PATCH' || $method === 'PUT') {
    $id = (int)($in['id'] ?? 0);
    if (!$id) json_out(['ok'=>false,'error'=>'id required'], 422);
    $f = $fields($in); $f['id'] = $id;
    $sql = 'UPDATE plans SET code=:code,group_code=:group_code,name=:name,description=:description,
            billing_period=:billing_period,price_cents=:price_cents,currency=:currency,trial_days=:trial_days,
            features=:features,is_active=:is_active,is_featured=:is_featured,sort_order=:sort_order WHERE id=:id';
    $pdo->prepare($sql)->execute($f);
    json_out(['ok'=>true]);
}

if ($method === 'DELETE') {
    $id = (int)($in['id'] ?? ($_GET['id'] ?? 0));
    if (!$id) json_out(['ok'=>false,'error'=>'id required'], 422);
    // Soft-deactivate (keeps invoices/subscriptions referencing it valid).
    $pdo->prepare('UPDATE plans SET is_active=0 WHERE id=?')->execute([$id]);
    json_out(['ok'=>true]);
}
json_out(['ok'=>false,'error'=>'Method not allowed'], 405);
