<?php
// Admin: comp a user onto a plan, OR mark a manual invoice paid, OR cancel a sub.
require __DIR__ . '/../../includes/bootstrap.php';
require_admin();
global $pdo;
$in = json_in();
$action = (string)($in['action'] ?? 'comp');

if ($action === 'comp') {
    // Grant a plan to a user by email (free comp, no charge).
    $email = strtolower(trim((string)($in['email'] ?? '')));
    $plan  = plan_get((int)($in['plan_id'] ?? 0));
    if ($email === '' || !$plan) json_out(['ok'=>false,'error'=>'email and plan_id required'], 422);
    $u = $pdo->prepare('SELECT id FROM users WHERE email=?'); $u->execute([$email]);
    $uid = $u->fetchColumn();
    if (!$uid) json_out(['ok'=>false,'error'=>'No user with that email'], 404);
    $res = activate_subscription((int)$uid, $plan, [
        'provider'=>'manual', 'status'=>'comp', 'final_cents'=>0, 'discount_cents'=>(int)$plan['price_cents'], 'paid'=>true,
    ]);
    json_out(['ok'=>true, 'result'=>$res]);
}

if ($action === 'mark_paid') {
    // Confirm an offline/bank-transfer invoice; activates the held subscription.
    $invId = (int)($in['invoice_id'] ?? 0);
    $inv = invoice_get($invId);
    if (!$inv) json_out(['ok'=>false,'error'=>'Invoice not found'], 404);
    $pdo->prepare("UPDATE invoices SET status='paid', amount_paid_cents=total_cents, paid_at=NOW() WHERE id=?")
        ->execute([$invId]);
    if ($inv['subscription_id']) {
        $pdo->prepare("UPDATE subscriptions SET status='active', updated_at=NOW()
                        WHERE id=? AND status IN ('past_due','trialing')")
            ->execute([(int)$inv['subscription_id']]);
    }
    json_out(['ok'=>true]);
}

if ($action === 'cancel') {
    $subId = (int)($in['subscription_id'] ?? 0);
    $now   = !empty($in['immediate']);
    if ($now) {
        $pdo->prepare("UPDATE subscriptions SET status='canceled', canceled_at=NOW(), updated_at=NOW() WHERE id=?")
            ->execute([$subId]);
    } else {
        $pdo->prepare("UPDATE subscriptions SET cancel_at_period_end=1, updated_at=NOW() WHERE id=?")
            ->execute([$subId]);
    }
    json_out(['ok'=>true]);
}
json_out(['ok'=>false,'error'=>'Unknown action'], 400);
