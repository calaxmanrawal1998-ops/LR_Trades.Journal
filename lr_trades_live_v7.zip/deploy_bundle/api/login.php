<?php
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$body     = json_in();
$email    = strtolower(trim($body['email'] ?? ''));
$password = (string) ($body['password'] ?? '');

if ($email === '' || $password === '') {
    json_out(['error' => 'Email and password are required.'], 422);
}

// Rate limit before touching the database (blocks credential stuffing).
$rl = lr_rate_check($pdo, $config['ratelimit'], 'login', $email);
if (!$rl['allowed']) {
    lr_rate_block($rl); // sends 429 + Retry-After and exits
}

$stmt = $pdo->prepare('SELECT id, email, password_hash, display_name, email_verified FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

// Use the same generic message whether the email or the password
// is wrong — don't reveal which accounts exist.
if (!$user || !password_verify($password, $user['password_hash'])) {
    lr_rate_record($pdo, 'login', $email, false);
    json_out(['error' => 'Incorrect email or password.'], 401);
}

// Optionally require a confirmed email before allowing sign-in.
if (!empty($config['require_verified_email']) && (int)$user['email_verified'] !== 1) {
    // Not a credential failure — don't count it toward lockout.
    json_out([
        'error'       => 'Please verify your email before signing in. Check your inbox for the confirmation link.',
        'unverified'  => true,
    ], 403);
}

// Good credentials — record success (also clears this account's failures).
lr_rate_record($pdo, 'login', $email, true);

// Rehash if PHP's default cost/algorithm has since changed.
if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
    $newHash = password_hash($password, PASSWORD_DEFAULT);
    $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
        ->execute([$newHash, $user['id']]);
}

$pdo->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?')
    ->execute([$user['id']]);

session_regenerate_id(true);
$_SESSION['user_id'] = (int) $user['id'];

json_out([
    'ok'   => true,
    'user' => [
        'id'    => (int) $user['id'],
        'email' => $user['email'],
        'name'  => $user['display_name'],
    ],
]);
