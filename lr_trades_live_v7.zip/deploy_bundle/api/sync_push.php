<?php
require __DIR__ . '/../includes/bootstrap.php';
$userId = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$body  = json_in();
$store = $body['store'] ?? '';
if (!in_array($store, ['trades', 'prop', 'notes', 'goals'], true)) {
    json_out(['error' => 'Invalid store'], 422);
}

// Accept either {doc:{...}} or {docs:[{...},...]} for bulk migration.
$docs = [];
if (isset($body['docs']) && is_array($body['docs'])) {
    $docs = $body['docs'];
} elseif (isset($body['doc']) && is_array($body['doc'])) {
    $docs = [$body['doc']];
} else {
    json_out(['error' => 'No doc(s) provided'], 422);
}

$sql = 'INSERT INTO journal_docs (user_id, store, item_id, data)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE data = VALUES(data)';
$stmt = $pdo->prepare($sql);

$saved = 0;
$pdo->beginTransaction();
try {
    foreach ($docs as $doc) {
        // The app keys everything by a string `id`.
        $itemId = (string)($doc['id'] ?? '');
        if ($itemId === '') continue;
        $stmt->execute([$userId, $store, $itemId, json_encode($doc)]);
        $saved++;
    }
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('sync_push failed: ' . $e->getMessage());
    json_out(['error' => 'Save failed'], 500);
}

json_out(['ok' => true, 'saved' => $saved]);
