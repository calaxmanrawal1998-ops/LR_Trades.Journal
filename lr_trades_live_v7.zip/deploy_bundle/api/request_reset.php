<?php
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$body  = json_in();
$email = strtolower(trim($body['email'] ?? ''));

// Rate limit to stop attackers flooding a victim's inbox.
$rl = lr_rate_check($pdo, $config['ratelimit'], 'reset_request', $email ?: null);
if (!$rl['allowed']) lr_rate_block($rl);

// Always return the same response so callers can't tell which emails exist.
$generic = ['ok' => true, 'message' => 'If that email is registered, a reset link is on its way.'];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    lr_rate_record($pdo, 'reset_request', $email ?: null, false);
    json_out($generic);
}

$stmt = $pdo->prepare('SELECT id, display_name FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user) {
    $raw  = lr_issue_token($pdo, (int)$user['id'], 'reset', (int)$config['reset_ttl']);
    $link = rtrim($config['app_url'], '/') . $config['reset_page'] . '?token=' . $raw;
    $mins = (int)round($config['reset_ttl'] / 60);
    $html = lr_email_shell(
        'Reset your password',
        'We received a request to reset your LR_TRADES password. Click below to choose a new one. '
        . 'This link expires in about ' . $mins . ' minute(s) and can be used once.',
        'Reset password',
        $link
    );
    lr_send_mail($config['mail'], $email, $user['display_name'] ?: $email, 'Reset your LR_TRADES password', $html);
}

lr_rate_record($pdo, 'reset_request', $email ?: null, true);
json_out($generic);
