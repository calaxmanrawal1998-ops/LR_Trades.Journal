<?php
require __DIR__ . '/../includes/bootstrap.php';

// Returns the current user if a session exists, else 401.
// The front end calls this on page load to decide: show the
// login screen, or show the dashboard.
if (empty($_SESSION['user_id'])) {
    json_out(['authenticated' => false], 401);
}

$stmt = $pdo->prepare('SELECT id, email, display_name FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    // User was deleted but cookie lingers — treat as logged out.
    session_destroy();
    json_out(['authenticated' => false], 401);
}

$billing = entitlements_for((int) $user['id']);

json_out([
    'authenticated' => true,
    'user' => [
        'id'    => (int) $user['id'],
        'email' => $user['email'],
        'name'  => $user['display_name'],
    ],
    // Lets the journal decide whether to gate access and what to show.
    'billing' => [
        'entitled'   => $billing['entitled'],
        'paywall'    => $billing['paywall'],
        'is_admin'   => $billing['is_admin'],
        'status'     => $billing['status'],
        'plan_name'  => $billing['plan_name'],
        'plan_code'  => $billing['plan_code'],
        'period_end' => $billing['period_end'],
    ],
]);
