<?php
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$body  = json_in();
$token = (string)($body['token'] ?? '');
$pw    = (string)($body['password'] ?? '');

if (strlen($pw) < 8) {
    json_out(['error' => 'Password must be at least 8 characters.'], 422);
}

$userId = lr_consume_token($pdo, $token, 'reset');
if ($userId === null) {
    json_out(['error' => 'This reset link is invalid or has expired. Please request a new one.'], 400);
}

$hash = password_hash($pw, PASSWORD_DEFAULT); // bcrypt, same as register/login

$pdo->beginTransaction();
try {
    $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([$hash, $userId]);
    // Resetting via the emailed link also proves control of the mailbox.
    $pdo->prepare('UPDATE users SET email_verified = 1, verified_at = COALESCE(verified_at, NOW()) WHERE id = ?')
        ->execute([$userId]);
    $pdo->prepare("UPDATE email_tokens SET used_at = NOW() WHERE user_id = ? AND purpose = 'reset' AND used_at IS NULL")
        ->execute([$userId]);
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('reset_password failed: ' . $e->getMessage());
    json_out(['error' => 'Could not reset password.'], 500);
}

// Clear any login lockout for this account.
$stmt = $pdo->prepare('SELECT email FROM users WHERE id = ?');
$stmt->execute([$userId]);
$email = (string)$stmt->fetchColumn();
$pdo->prepare("DELETE FROM auth_attempts WHERE email = ? AND action = 'login' AND success = 0")
    ->execute([$email]);

json_out(['ok' => true, 'message' => 'Password updated. You can now sign in.']);
