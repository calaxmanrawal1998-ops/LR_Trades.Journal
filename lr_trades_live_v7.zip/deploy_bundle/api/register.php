<?php
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$body        = json_in();
$email       = strtolower(trim($body['email'] ?? ''));
$password    = (string) ($body['password'] ?? '');
$displayName = trim($body['name'] ?? '') ?: null;

// ---- Validation --------------------------------------------------
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_out(['error' => 'Please enter a valid email address.'], 422);
}
if (strlen($password) < 8) {
    json_out(['error' => 'Password must be at least 8 characters.'], 422);
}

// ---- Create user -------------------------------------------------
$hash = password_hash($password, PASSWORD_DEFAULT); // bcrypt

try {
    $stmt = $pdo->prepare(
        'INSERT INTO users (email, password_hash, display_name) VALUES (?, ?, ?)'
    );
    $stmt->execute([$email, $hash, $displayName]);
} catch (PDOException $e) {
    // 23000 = integrity constraint (duplicate email)
    if ($e->getCode() === '23000') {
        json_out(['error' => 'An account with that email already exists.'], 409);
    }
    error_log('Register failed: ' . $e->getMessage());
    json_out(['error' => 'Could not create account.'], 500);
}

$userId = (int) $pdo->lastInsertId();

// Send a verification email (best-effort; a failure here shouldn't block signup).
$raw  = lr_issue_token($pdo, $userId, 'verify', (int)$config['verify_ttl']);
$link = rtrim($config['app_url'], '/') . '/api/verify_email.php?token=' . $raw;
$html = lr_email_shell(
    'Confirm your email',
    'Welcome to LR_TRADES. Confirm your email address to activate your account.',
    'Verify email',
    $link
);
lr_send_mail($config['mail'], $email, $displayName ?: $email, 'Confirm your LR_TRADES email', $html);

// When verification is required, do NOT start a session — the user must
// confirm first. Otherwise, log them straight in (original behaviour).
if (!empty($config['require_verified_email'])) {
    json_out([
        'ok'      => true,
        'verify'  => true,
        'message' => 'Account created. Check your email to confirm your address, then sign in.',
        'user'    => ['id' => $userId, 'email' => $email, 'name' => $displayName],
    ], 201);
}

session_regenerate_id(true);
$_SESSION['user_id'] = $userId;

json_out([
    'ok'   => true,
    'user' => ['id' => $userId, 'email' => $email, 'name' => $displayName],
], 201);
