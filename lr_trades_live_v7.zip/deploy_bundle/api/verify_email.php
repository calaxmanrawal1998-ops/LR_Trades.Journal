<?php
require __DIR__ . '/../includes/bootstrap.php';

// GET ?token=...  -> confirm the address, then render a small result page.
$token  = (string)($_GET['token'] ?? '');
$userId = lr_consume_token($pdo, $token, 'verify');

if ($userId !== null) {
    $pdo->prepare('UPDATE users SET email_verified = 1, verified_at = COALESCE(verified_at, NOW()) WHERE id = ?')
        ->execute([$userId]);
    $ok = true;
} else {
    $ok = false;
}

$signin = htmlspecialchars(rtrim($config['app_url'], '/') . $config['signin_page'], ENT_QUOTES);
$title  = $ok ? 'Email verified' : 'Link expired';
$msg    = $ok
    ? 'Your email address is confirmed. You can now sign in and your trades will sync across devices.'
    : 'This verification link is invalid or has expired. Sign in and use "Resend verification" to get a fresh one.';
$accent = $ok ? '#10b981' : '#e0a03a';

header('Content-Type: text/html; charset=utf-8');
echo '<!doctype html><html lang="en"><head><meta charset="utf-8">'
   . '<meta name="viewport" content="width=device-width,initial-scale=1">'
   . '<title>' . $title . ' &middot; LR_TRADES</title></head>'
   . '<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;'
   . 'background:radial-gradient(1200px 800px at 20% 10%,#0e241a,#060b09);'
   . 'font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#dfeee8;">'
   . '<div style="max-width:420px;padding:36px;background:rgba(17,26,22,.72);border:1px solid #1e2f27;'
   . 'border-radius:18px;backdrop-filter:blur(14px);text-align:center;">'
   . '<div style="font-size:12px;letter-spacing:3px;color:' . $accent . ';font-weight:700;">LR_TRADES</div>'
   . '<h1 style="font-size:22px;margin:14px 0 8px;color:#fff;">' . $title . '</h1>'
   . '<p style="font-size:15px;line-height:1.55;color:#c3d6ce;margin:0 0 22px;">' . $msg . '</p>'
   . '<a href="' . $signin . '" style="display:inline-block;background:' . $accent . ';color:#04120c;'
   . 'text-decoration:none;font-weight:600;padding:12px 24px;border-radius:10px;">Go to sign in</a>'
   . '</div></body></html>';
