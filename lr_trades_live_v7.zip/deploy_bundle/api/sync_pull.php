<?php
require __DIR__ . '/../includes/bootstrap.php';
$userId = require_login();

$stmt = $pdo->prepare('SELECT store, item_id, data FROM journal_docs WHERE user_id = ?');
$stmt->execute([$userId]);

$out = ['trades' => [], 'prop' => [], 'notes' => [], 'goals' => []];
foreach ($stmt as $row) {
    $store = $row['store'];
    if (!isset($out[$store])) $out[$store] = [];
    // data is already a JSON string; decode so the client gets real objects.
    $out[$store][] = json_decode($row['data'], true);
}

json_out(['ok' => true, 'data' => $out]);
