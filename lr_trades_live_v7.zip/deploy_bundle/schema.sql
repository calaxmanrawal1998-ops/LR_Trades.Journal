-- ============================================================
--  LR TRADES — Database schema (MySQL / MariaDB)
--  Run ONCE in hPanel → Databases → phpMyAdmin → SQL tab,
--  after you create the database + database user.
--
--  Design: a per-user DOCUMENT STORE that mirrors the app's
--  four IndexedDB stores (trades, prop, notes, goals). Each
--  row holds one journal object as JSON, keyed by the app's
--  own string id. This is lossless — whatever your journal
--  saves locally is exactly what comes back, across devices.
-- ============================================================

-- --- USERS -------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    email           VARCHAR(190) NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,          -- bcrypt (never plain text)
    display_name    VARCHAR(80)  DEFAULT NULL,
    created_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at   TIMESTAMP    NULL DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- JOURNAL DOCUMENTS --------------------------------------
-- store   = 'trades' | 'prop' | 'notes' | 'goals'
-- item_id = the journal's own string id (e.g. "1719912345678")
-- data    = the full object as JSON (LONGTEXT holds base64 chart
--           images too). Composite PK makes upserts natural and
--           keeps each user's ids independent.
CREATE TABLE IF NOT EXISTS journal_docs (
    user_id     INT UNSIGNED    NOT NULL,
    store       VARCHAR(16)     NOT NULL,
    item_id     VARCHAR(64)     NOT NULL,
    data        LONGTEXT        NOT NULL,
    updated_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
                                ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, store, item_id),
    KEY idx_user_store (user_id, store),
    CONSTRAINT fk_docs_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
