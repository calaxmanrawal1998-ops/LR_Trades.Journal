-- ============================================================
--  LR TRADES — Billing / subscriptions migration (v2 -> v3)
--  Run ONCE in hPanel -> Databases -> phpMyAdmin -> SQL tab,
--  AFTER schema.sql and schema_v2.sql.
--
--  Adds: admin flag, subscription plans (monthly / yearly /
--  lifetime), coupons (percent / fixed / 100%-off), per-user
--  subscriptions, invoices, coupon redemptions, a webhook/event
--  log (for the live processor in step 2), and a small key/value
--  settings table so the creator can tune rules WITHOUT editing
--  config.php. Everything is provider-agnostic.
-- ============================================================

-- --- USERS: admin flag -------------------------------------
-- Emails listed in config['billing']['admin_emails'] are ALSO
-- treated as admins, so you can bootstrap access without SQL.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS is_admin TINYINT(1) NOT NULL DEFAULT 0;

-- --- APP SETTINGS (creator-tunable rules) ------------------
CREATE TABLE IF NOT EXISTS app_settings (
    skey        VARCHAR(64)  NOT NULL,
    sval        TEXT         NULL,
    updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                             ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (skey)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO app_settings (skey, sval) VALUES
  ('paywall_enabled',       '0'),      -- 1 = journal requires an active plan
  ('default_currency',      'USD'),
  ('trial_days_default',    '0'),
  ('grace_days',            '3'),      -- past_due grace before access is cut
  ('active_gateway',        'manual'), -- manual until a processor is connected
  ('allow_bank_transfer',   '1'),      -- show offline/bank-transfer option
  ('brand_name',            'LR_TRADES'),
  ('support_email',         ''),
  ('invoice_prefix',        'LR'),
  ('invoice_footer',        'Thank you for trading with LR_TRADES.'),
  ('tax_note',              '')
ON DUPLICATE KEY UPDATE skey = skey;  -- never overwrite existing values on re-run

-- --- PLANS --------------------------------------------------
-- One row per buyable price. Pair a tier's monthly & yearly by
-- giving them the same group_code (e.g. 'pro'). features = JSON
-- array of strings shown on the pricing card.
CREATE TABLE IF NOT EXISTS plans (
    id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code           VARCHAR(40)  NOT NULL,               -- unique, e.g. 'pro_month'
    group_code     VARCHAR(40)  NOT NULL DEFAULT 'default', -- tier, e.g. 'pro'
    name           VARCHAR(80)  NOT NULL,               -- tier name, e.g. 'Pro'
    description    VARCHAR(255) NULL,
    billing_period ENUM('month','year','lifetime','once') NOT NULL DEFAULT 'month',
    price_cents    INT UNSIGNED NOT NULL DEFAULT 0,     -- 0 = free plan
    currency       CHAR(3)      NOT NULL DEFAULT 'USD',
    trial_days     INT UNSIGNED NOT NULL DEFAULT 0,
    features       JSON         NULL,
    is_active      TINYINT(1)   NOT NULL DEFAULT 1,
    is_featured    TINYINT(1)   NOT NULL DEFAULT 0,     -- "most popular" highlight
    sort_order     INT          NOT NULL DEFAULT 0,
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_plan_code (code),
    KEY idx_group (group_code),
    KEY idx_active (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- COUPONS ------------------------------------------------
-- kind='percent' value 0..100  (value=100 => free)
-- kind='fixed'   value in the smallest currency unit (cents)
-- applies_to = JSON array of plan group_codes or plan ids; NULL = all plans
CREATE TABLE IF NOT EXISTS coupons (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code             VARCHAR(40)  NOT NULL,             -- stored UPPERCASE
    kind             ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
    value            INT UNSIGNED NOT NULL,
    currency         CHAR(3)      NULL,                 -- for 'fixed'
    duration         ENUM('once','repeating','forever') NOT NULL DEFAULT 'once',
    duration_months  INT UNSIGNED NULL,                 -- for 'repeating'
    max_redemptions  INT UNSIGNED NULL,                 -- NULL = unlimited
    times_redeemed   INT UNSIGNED NOT NULL DEFAULT 0,
    per_user_limit   INT UNSIGNED NOT NULL DEFAULT 1,
    applies_to       JSON         NULL,
    min_amount_cents INT UNSIGNED NULL,
    starts_at        DATETIME     NULL,
    expires_at       DATETIME     NULL,
    is_active        TINYINT(1)   NOT NULL DEFAULT 1,
    note             VARCHAR(190) NULL,
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_coupon_code (code),
    KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- SUBSCRIPTIONS ------------------------------------------
CREATE TABLE IF NOT EXISTS subscriptions (
    id                       INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id                  INT UNSIGNED NOT NULL,
    plan_id                  INT UNSIGNED NULL,
    plan_code                VARCHAR(40)  NULL,          -- snapshot (survives plan delete)
    status                   ENUM('trialing','active','past_due','canceled','expired','comp')
                                          NOT NULL DEFAULT 'active',
    provider                 VARCHAR(20)  NOT NULL DEFAULT 'manual',
    provider_customer_id     VARCHAR(190) NULL,
    provider_subscription_id VARCHAR(190) NULL,
    coupon_id                INT UNSIGNED NULL,
    current_period_start     DATETIME     NULL,
    current_period_end       DATETIME     NULL,          -- NULL = never expires (lifetime/comp)
    cancel_at_period_end     TINYINT(1)   NOT NULL DEFAULT 0,
    canceled_at              DATETIME     NULL,
    created_at               DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at               DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user_status (user_id, status),
    KEY idx_period_end (current_period_end),
    KEY idx_provider_sub (provider_subscription_id),
    CONSTRAINT fk_sub_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- INVOICES -----------------------------------------------
CREATE TABLE IF NOT EXISTS invoices (
    id                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    number              VARCHAR(32)  NOT NULL,           -- e.g. LR-2026-000001
    user_id             INT UNSIGNED NOT NULL,
    subscription_id     INT UNSIGNED NULL,
    plan_code           VARCHAR(40)  NULL,
    description         VARCHAR(190) NULL,
    currency            CHAR(3)      NOT NULL DEFAULT 'USD',
    subtotal_cents      INT UNSIGNED NOT NULL DEFAULT 0,
    discount_cents      INT UNSIGNED NOT NULL DEFAULT 0,
    tax_cents           INT UNSIGNED NOT NULL DEFAULT 0,
    total_cents         INT UNSIGNED NOT NULL DEFAULT 0,
    amount_paid_cents   INT UNSIGNED NOT NULL DEFAULT 0,
    status              ENUM('draft','open','paid','void','refunded') NOT NULL DEFAULT 'open',
    coupon_code         VARCHAR(40)  NULL,
    provider            VARCHAR(20)  NOT NULL DEFAULT 'manual',
    provider_invoice_id VARCHAR(190) NULL,
    line_items          JSON         NULL,
    customer_snapshot   JSON         NULL,
    issued_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paid_at             DATETIME     NULL,
    created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_invoice_number (number),
    KEY idx_user (user_id),
    KEY idx_status (status),
    CONSTRAINT fk_inv_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- COUPON REDEMPTIONS -------------------------------------
CREATE TABLE IF NOT EXISTS coupon_redemptions (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    coupon_id       INT UNSIGNED NOT NULL,
    user_id         INT UNSIGNED NOT NULL,
    subscription_id INT UNSIGNED NULL,
    invoice_id      INT UNSIGNED NULL,
    redeemed_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_coupon_user (coupon_id, user_id),
    CONSTRAINT fk_redeem_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- BILLING EVENTS (webhook log / idempotency) ------------
-- Used by the live processor in step 2 so a replayed webhook is
-- processed at most once.
CREATE TABLE IF NOT EXISTS billing_events (
    id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    provider          VARCHAR(20)  NOT NULL,
    event_type        VARCHAR(80)  NULL,
    provider_event_id VARCHAR(190) NULL,
    payload           JSON         NULL,
    status            VARCHAR(20)  NOT NULL DEFAULT 'received',
    created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_provider_event (provider, provider_event_id),
    KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  OPTIONAL starter data — a Free tier + Pro monthly/yearly.
--  Delete or edit freely from the admin dashboard afterwards.
-- ============================================================
INSERT INTO plans (code, group_code, name, description, billing_period, price_cents, currency, trial_days, features, is_active, is_featured, sort_order)
VALUES
  ('free',       'free', 'Free',  'Get started and journal your trades.', 'month',    0,    'USD', 0,
      JSON_ARRAY('Up to 50 trades','1 chart per trade','Local + cloud sync'), 1, 0, 0),
  ('pro_month',  'pro',  'Pro',   'Everything, unlimited.',                'month',    1500, 'USD', 7,
      JSON_ARRAY('Unlimited trades','Unlimited charts','Prop-firm tracking','Economic calendar','Priority support'), 1, 1, 10),
  ('pro_year',   'pro',  'Pro',   'Everything, unlimited. 2 months free.', 'year',     15000,'USD', 7,
      JSON_ARRAY('Unlimited trades','Unlimited charts','Prop-firm tracking','Economic calendar','Priority support'), 1, 1, 11)
ON DUPLICATE KEY UPDATE code = code;  -- no-op if already present
