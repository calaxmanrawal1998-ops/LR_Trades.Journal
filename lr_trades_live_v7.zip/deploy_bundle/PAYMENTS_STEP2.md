# LR_TRADES — Step 2: Live Payments (Razorpay + Crypto)

You're registering the business in **India**, selling to **India + international**,
and want **cards and crypto** with **subscriptions**. This document explains the
recommended stack, the constraints that shape it, and exactly what to fill in.

The scaffolding is already in the code (gateways + webhook). It is **sandbox-ready,
not yet tested** — finish it against each provider's test mode before going live.

---

## Recommended stack

| Rail | Provider | Why |
|---|---|---|
| Cards / UPI / netbanking / **international** + **subscriptions** | **Razorpay** | India-registered friendly; native Subscriptions that handle the RBI e-mandate flow; 160+ currencies; real sandbox; good webhooks. |
| **Crypto** (300+ coins) | **NOWPayments** | Non-custodial, low fee, sandbox + webhooks. (Coinbase Commerce stops serving non-US/Singapore merchants on 31 Mar 2026, so it's out.) |
| _Optional_ | Stripe | Only if you later open a US/UK entity. |

Both are already wired into the gateway layer (`includes/gateways.php`) and a single
webhook (`api/billing/webhook.php`). Switch between them anytime from **Admin →
Settings → Active gateway**.

---

## Constraints to know (important)

**1． RBI rules on recurring card payments (India).** Any subscription charged to an
Indian card must use an **e-mandate/AutoPay** set up with OTP/UPI-PIN, sends a
**72-hour pre-debit notification** before each renewal, requires **card
tokenization**, and needs **re-authentication for charges over ₹15,000**. You get
this for free by using **Razorpay Subscriptions** (the code already creates a
Subscription, not a raw charge) — don't try to auto-charge cards yourself.

**2． Crypto has no silent auto-renew.** You can't pull a renewal from a wallet.
Crypto plans are handled as **pay-per-term**: the user pays a hosted invoice each
cycle and access is granted for that plan's period on confirmation. Remind users
before expiry. (NOWPayments has a recurring API you can layer on later if wanted.)

**3． You are the merchant of record (tax/GST is yours).** As a gateway (not an MoR),
your India entity owns GST, invoicing, and export paperwork. Talk to a CA about
GST on digital services and, separately, about **crypto taxation** (India taxes
Virtual Digital Assets heavily — ~30% + 1% TDS — and accepting crypto adds
reporting overhead). If that burden isn't worth it, a Merchant-of-Record
(Paddle / Dodo Payments) would offload tax at a higher fee — say the word and I'll
wire that instead.

**4． Sequencing — code isn't the blocker.** You can't get API keys until the entity
exists and KYC passes. Do the business steps first (below), then finish + test the
integration.

---

## Onboarding sequence

1. **Register the India entity** (Pvt Ltd / LLP / proprietorship) — get PAN, and
   GSTIN if applicable. Open a current account.
2. **Razorpay:** sign up → complete KYC → **activate International Payments**
   (separate step, needs docs) → generate **TEST** API keys.
3. **NOWPayments:** sign up → create a store → get **API key** + **IPN secret** →
   set your receiving wallet(s).
4. Come back and finish the integration (checklist below) in **test mode**, verify
   end-to-end, then swap in live keys.

---

## Go-live checklist (what to fill in)

All of this lives in `includes/config.php` under `billing`:

**Razorpay**
- [ ] `razorpay.key_id`, `razorpay.key_secret` (test keys first).
- [ ] In the Razorpay dashboard, create a **Plan** for each recurring price
      (monthly, yearly) and map them: `razorpay.plan_ids = ['pro_month'=>'plan_...','pro_year'=>'plan_...']`.
- [ ] Add the webhook URL `…/api/billing/webhook.php?provider=razorpay`, set its
      secret, and put the same value in `razorpay.webhook_secret`. Subscribe to:
      `subscription.charged`, `subscription.activated`, `subscription.cancelled`,
      `subscription.halted`, `payment_link.paid`.
- [ ] Admin → Settings → Active gateway = **Razorpay**.

**NOWPayments**
- [ ] `nowpayments.api_key`, `nowpayments.ipn_secret`.
- [ ] Set the IPN callback in NOWPayments to `…/api/billing/webhook.php?provider=nowpayments`.
- [ ] Switch Active gateway to **Crypto — NOWPayments** when you want crypto checkout.

**Test (sandbox) before live**
- [ ] Subscribe to a monthly plan with a Razorpay test card → confirm the webhook
      creates an active subscription + a paid invoice, and the journal unlocks.
- [ ] Let a renewal fire (or simulate `subscription.charged`) → confirm the period
      extends on the **same** subscription and a new invoice appears.
- [ ] Cancel from the Razorpay side → confirm status flips to canceled.
- [ ] Pay a crypto invoice in NOWPayments sandbox → confirm access is granted.
- [ ] Verify a **100%-off coupon** still activates instantly (it bypasses the
      processor by design).

---

## What the code already does

- `includes/gateways.php` — `RazorpayGateway` (Subscriptions for month/year,
  Payment Links for one-time) and `NOWPaymentsGateway` (hosted crypto invoice),
  both returning a hosted-checkout redirect. Card data never touches your server.
- `api/billing/webhook.php` — verifies each provider's signature
  (Razorpay HMAC-SHA256; NOWPayments HMAC-SHA512 over sorted JSON), de-duplicates
  via `billing_events`, and activates / **renews** / cancels using the existing
  billing engine.
- `api/billing/subscribe.php` — routes zero-value (free / 100%-off) checkouts
  through the manual path so they never hit a processor.

## Things to verify against current docs while testing
- Exact Razorpay webhook payload paths (`payload.subscription.entity.notes`,
  `payload.payment.entity.amount`) and event names.
- NOWPayments IPN field names (`payment_status`, `order_id`, `price_amount`,
  `payment_id`) and the exact signature scheme.
- Currency handling: Razorpay subscription plans are created in a fixed currency —
  keep your plan's currency consistent with the Razorpay Plan you map.

When your sandbox keys are ready, share them (test keys only) or just tell me and
I'll tighten these adapters to the exact payloads and add anything missing
(proration, dunning emails, GST fields on invoices, NOWPayments recurring).
