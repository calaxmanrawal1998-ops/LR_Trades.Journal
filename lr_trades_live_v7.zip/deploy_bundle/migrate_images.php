<?php
/**
 * migrate_images.php — one-time migration (CLI ONLY).
 *
 * Walks journal_docs, moves inline "data:image/...;base64,..." blobs
 * (trade chartImages[].data and legacy chartImage) into files under
 * uploads/charts/<user>/, and rewrites the stored JSON to reference the
 * file URL instead. Idempotent: re-running skips already-migrated docs.
 *
 * USAGE (from this folder, on the server via SSH or hPanel terminal):
 *   php migrate_images.php --dry-run     # report only, writes nothing
 *   php migrate_images.php               # perform the migration
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("This script runs from the command line only.\n");
}

$dryRun = in_array('--dry-run', $argv, true);

// ---- Load config + open a DB connection (no session in CLI) ----
$config = require __DIR__ . '/includes/config.php';
$pdo = new PDO(
    sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', $config['db_host'], $config['db_name']),
    $config['db_user'], $config['db_pass'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
);

$uploadsRoot = __DIR__ . '/uploads';
$chartRoot   = $uploadsRoot . '/charts';
$extByType   = [IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];
$dataUriRe   = '#^data:image/[a-zA-Z.+-]+;base64,#';

$scanned = 0; $changed = 0; $moved = 0; $bytes = 0; $errors = 0;

// Replace any data-URI string with a stored file URL (or leave it be).
$offload = function (string $val, int $uid) use ($dataUriRe, $extByType, $chartRoot, $dryRun, &$moved, &$bytes, &$errors) {
    if (!preg_match($dataUriRe, $val)) return null;         // already a URL / not an image
    $bin = base64_decode(strtr(substr($val, strpos($val, ',') + 1), ' ', '+'), true);
    if ($bin === false) { $errors++; return null; }
    $info = @getimagesizefromstring($bin);
    if ($info === false || !isset($extByType[$info[2]])) { $errors++; return null; }
    $name = bin2hex(random_bytes(16)) . '.' . $extByType[$info[2]];
    $dir  = $chartRoot . '/' . $uid;
    if (!$dryRun) {
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) { $errors++; return null; }
        if (file_put_contents("$dir/$name", $bin) === false) { $errors++; return null; }
    }
    $moved++; $bytes += strlen($bin);
    return "/uploads/charts/$uid/$name";
};

// Walk a decoded doc, offloading images in place. Returns true if changed.
function walk(&$node, int $uid, callable $offload): bool {
    $changed = false;
    if (is_array($node)) {
        foreach ($node as $k => &$v) {
            if (is_string($v)) {
                $new = $offload($v, $uid);
                if ($new !== null) { $v = $new; $changed = true; }
            } elseif (is_array($v)) {
                if (walk($v, $uid, $offload)) $changed = true;
            }
        }
        unset($v);
    }
    return $changed;
}

$sel = $pdo->query('SELECT user_id, store, item_id, data FROM journal_docs ORDER BY user_id, store, item_id');
$upd = $pdo->prepare('UPDATE journal_docs SET data = ? WHERE user_id = ? AND store = ? AND item_id = ?');

while ($row = $sel->fetch()) {
    $scanned++;
    $doc = json_decode($row['data'], true);
    if (!is_array($doc)) continue;
    $uid = (int)$row['user_id'];

    if (walk($doc, $uid, $offload)) {
        $changed++;
        if (!$dryRun) {
            $upd->execute([
                json_encode($doc, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $row['user_id'], $row['store'], $row['item_id'],
            ]);
        }
    }
}

// Harden the uploads dir once.
if (!$dryRun && is_dir($chartRoot)) {
    $ht = $uploadsRoot . '/.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht,
            "php_flag engine off\n<FilesMatch \"\\.(?i:php[0-9]?|phtml|pl|py|cgi|asp|sh)$\">\n  Require all denied\n</FilesMatch>\n");
    }
}

$mb = number_format($bytes / 1048576, 2);
echo ($dryRun ? "[DRY RUN] " : "") . "Done.\n";
echo "  rows scanned : $scanned\n";
echo "  rows changed : $changed\n";
echo "  images moved : $moved ($mb MB)\n";
echo "  errors       : $errors\n";
if ($dryRun) echo "\nNothing was written. Re-run without --dry-run to apply.\n";
